#!/usr/bin/env python3
"""Screenshot explorer views with a local headless browser.

    python3 shot.py --html docs/architecture/explorer.html --out /tmp/shots
    python3 shot.py --html docs/architecture/explorer.html --out /tmp/shots --views global,action_encoder

Tries Chromium/Chrome first, then Firefox. Firefox from a snap cannot read /tmp,
so the page is copied under ~/.cache before launching.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import pathlib
import shutil
import signal
import subprocess
import sys

BROWSERS = [
    ("chromium", ["--headless", "--disable-gpu", "--no-sandbox"]),
    ("chromium-browser", ["--headless", "--disable-gpu", "--no-sandbox"]),
    ("google-chrome", ["--headless", "--disable-gpu", "--no-sandbox"]),
    ("google-chrome-stable", ["--headless", "--disable-gpu", "--no-sandbox"]),
    ("firefox", ["--headless"]),
]


def find_browser():
    for name, flags in BROWSERS:
        path = shutil.which(name)
        if path:
            return name, path, flags
    return None


def local_copy(html: pathlib.Path) -> pathlib.Path:
    """Firefox (snap) can only read $HOME; copy the output tree there if needed."""
    home = pathlib.Path.home().resolve()
    try:
        html.resolve().relative_to(home)
        return html
    except ValueError:
        pass
    digest = hashlib.sha1(str(html.resolve()).encode()).hexdigest()[:10]
    # A non-hidden path: the Firefox snap cannot read directories beginning with a dot.
    target = home / "architecture-explorer-tmp" / "pages" / digest
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(html.parent, target)
    return target / html.name


def shot(name, path, flags, html, view, out, width, height):
    url = html.resolve().as_uri()
    if view and view != "global":
        url += "#/" + view
    elif view == "global":
        url += "#/global"
    target = out / f"{view or 'global'}.png"
    # Firefox from a snap can only write inside $HOME; render there, then move.
    staging = pathlib.Path.home() / "architecture-explorer-tmp" / "shots"
    staging.mkdir(parents=True, exist_ok=True)
    rendered = staging / f"{name}-{view or 'global'}.png"
    rendered.unlink(missing_ok=True)
    cmd = [path, *flags, f"--screenshot={rendered}", f"--window-size={width},{height}", url]
    # Do not capture the browser's pipes: its content processes inherit them and
    # keep the pipe open after the parent exits, which looks like a hang.
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    try:
        proc.wait(timeout=90)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:
            pass
        raise RuntimeError(f"{name} timed out after 90s")
    if not rendered.exists():
        raise RuntimeError(f"{name} did not write {rendered}")
    shutil.move(str(rendered), target)
    return target


def main(argv=None):
    parser = argparse.ArgumentParser(description="Screenshot explorer views.")
    parser.add_argument("--html", required=True)
    parser.add_argument("--out", required=True, help="output directory")
    parser.add_argument("--views", default="global", help="comma-separated view ids")
    parser.add_argument("--size", default="1680x1000")
    args = parser.parse_args(argv)

    browser = find_browser()
    if not browser:
        print("no headless browser found (chromium/chrome/firefox); open the HTML manually")
        return 2
    name, path, flags = browser
    html = local_copy(pathlib.Path(args.html).resolve())
    out = pathlib.Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    width, height = (int(x) for x in args.size.lower().split("x"))

    failures = 0
    for view in [v.strip() for v in args.views.split(",") if v.strip()]:
        try:
            target = shot(name, path, flags, html, view, out, width, height)
            print(f"wrote {target}")
        except Exception as exc:
            failures += 1
            print(f"FAIL  {view}: {exc}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
