#!/usr/bin/env python3
"""Validate an architecture-explorer spec before building.

Errors mean the explorer would be broken or misleading:

    * duplicate view / node ids
    * a view whose parent does not exist
    * a drill target that does not exist
    * an edge endpoint that does not exist
    * a view/node code pointer that does not resolve
    * a non-global view reachable by nobody (not in tree and not drilled into)
    * a leaf view with no code pointer and no explicit terminal reason
    * an edge that touches a kind: note callout
    * an edge out of a repeated container into an internal part

Warnings are layout / evidence smells that a human should look at:

    * node outside the canvas
    * view without source
    * unresolved {placeholder} that no preset or view var can fill
    * a shape/einsum letter with no entry in symbols:
    * a drillable node with no edges and no kind: note (looks like a callout)
    * an RMSNorm/adaRMS node that does not name pre-attention / pre-FFN / final
    * a leaf without terminal: true

Usage:
    python3 check.py --spec docs/architecture/spec --repo-root .
    python3 check.py --spec docs/architecture/spec --strict
"""
from __future__ import annotations

import argparse
import pathlib
import re
import sys

from build import load_spec

PLACEHOLDER = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")
EINSUM = re.compile(r"[A-Za-z0-9,]+(?:\s*->\s*[A-Za-z0-9,]+)")
LETTER_TOKEN = re.compile(r"[A-Za-z][A-Za-z0-9_]*")

# Heuristics for the "containment edge" mistake: an edge out of a repeated
# container (18x block, layer stack, loop) into an internal part is almost
# always navigation, not data flow.
REPEAT_RE = re.compile(r"(?:\d+\s*[×xX]|[×xX]\s*\d+|stack|loop|repeat)", re.I)
INTERNAL_HINTS = ("ffn", "mlp", "attention", "attn", "norm", "rmsnorm", "adarms")
BOUNDARY_HINTS = ("final", "output", "out", "head", "logits")
NORM_HINTS = ("rmsnorm", "adarms")
STAGE_HINTS = (
    "pre-attn",
    "pre-ffn",
    "pre-norm",
    "pre norm",
    "post",
    "final",
    "attn",
    "attention",
    "ffn",
    "ffw",
    "mlp",
)


def einsum_letters(text) -> set[str]:
    out = set()
    for match in EINSUM.finditer(str(text or "")):
        out.update(ch for ch in match.group(0) if ch.isalpha())
    return out


def shape_letters(text) -> set[str]:
    out = set()
    source = str(text or "")
    for match in LETTER_TOKEN.finditer(source):
        token = match.group(0)
        if len(token) == 1:
            before = source[match.start() - 1] if match.start() else ""
            after = source[match.end()] if match.end() < len(source) else ""
            # "30k" / "1e3" are literals, not shape symbols.
            if before.isdigit() or after.isdigit():
                continue
            out.add(token)
        elif token.isupper():
            out.update(token)
    return out


def run(spec_dir: pathlib.Path, repo_root: pathlib.Path | None, strict: bool):
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data, _ = load_spec(spec_dir, repo_root=repo_root)
    except Exception as exc:
        return [f"{type(exc).__name__}: {exc}"], [], {}

    decisions = spec_dir / "decisions.md"
    if not decisions.exists():
        warnings.append(
            "decisions.md missing: grill the exploration plan and record scope/branch cut/terminal floor"
        )
    elif "TODO" in decisions.read_text(encoding="utf-8", errors="replace"):
        warnings.append("decisions.md still contains TODO: the grill is not finished")

    views = data["views"]
    presets = data["presets"]
    default = data["defaultPreset"] or {}

    # glossary / plain-language layer
    glossary = data.get("glossary") or {}
    terms = glossary.get("terms") or []
    term_ids = {}
    aliases = {}
    for term in terms:
        tid = term.get("id")
        if tid in term_ids:
            errors.append(f"glossary: duplicate term id {tid!r}")
        term_ids[tid] = term
        if not term.get("plain"):
            warnings.append(f"glossary/{tid}: no plain-language sentence")
        for vid in term.get("views") or []:
            if vid != "global" and vid not in views:
                errors.append(f"glossary/{tid}: views entry {vid!r} is not a view")
        for alias in [term.get("term")] + list(term.get("aliases") or []):
            key = str(alias).lower()
            if key in aliases and aliases[key] != tid:
                warnings.append(
                    f"glossary: alias {alias!r} is claimed by both {aliases[key]!r} and {tid!r}"
                )
            aliases.setdefault(key, tid)
    plain_groups = [("global", data.get("global", {}).get("plain_terms") or [])]
    plain_groups += [(vid, view.get("plain_terms") or []) for vid, view in views.items()]
    for vid, ids in plain_groups:
        for tid in ids:
            if tid not in term_ids:
                errors.append(f"{vid}: plain_terms entry {tid!r} is not a glossary term")

    # shape / einsum symbol coverage: every letter shown on the canvas should
    # have a meaning, and the meaning should be more than an empty string.
    global_symbols = data.get("symbols") or {}
    for letter, entry in global_symbols.items():
        if not entry.get("detail"):
            warnings.append(f"symbols/{letter}: definition has no detail")
    for vid, view in views.items():
        defs = set(global_symbols) | set(view.get("symbols") or {})
        for letter, entry in (view.get("symbols") or {}).items():
            if not entry.get("detail"):
                warnings.append(f"{vid}/symbols/{letter}: definition has no detail")
        used = set()
        for node in view["nodes"]:
            used |= einsum_letters(node.get("title"))
            used |= einsum_letters(node.get("sub"))
            shape = node.get("shape") or {}
            if isinstance(shape, dict):
                used |= shape_letters(shape.get("sym"))
                used |= shape_letters(shape.get("real"))
        missing = sorted(used - defs)
        if missing:
            warnings.append(
                f"{vid}: shape/einsum letters without a definition: {', '.join(missing)}"
            )
    for nid, node in (data.get("globalNodes") or {}).items():
        used = einsum_letters(node.get("title")) | einsum_letters(node.get("sub"))
        shape = node.get("shape")
        if isinstance(shape, str):
            used |= shape_letters(shape)
        missing = sorted(used - set(global_symbols))
        if missing:
            warnings.append(
                f"global/{nid}: shape/einsum letters without a definition: {', '.join(missing)}"
            )

    # ids / parents / drills
    for vid, view in views.items():
        if view["parent"] != "global" and view["parent"] not in views:
            errors.append(f"{vid}: parent {view['parent']!r} does not exist")
        for node in view["nodes"]:
            drill = node.get("drill")
            if drill and drill not in views:
                errors.append(f"{vid}/{node['id']}: drill target {drill!r} does not exist")
        for edge in view["edges"]:
            for end in ("from", "to"):
                if edge.get(end) and edge[end] not in {n["id"] for n in view["nodes"]}:
                    errors.append(f"{vid}: edge {end}={edge[end]!r} is not a node in this view")

    # parameter ownership: "these weights train" is a claim about one
    # configuration, so each tag names its config and each matrix row cites the
    # line that decides it.
    PARAM_STATES = {"train", "frozen", "n-a"}
    TABLE_MARKS = {"train", "frozen", "n-a", "na"}
    matrix_views = {
        vid
        for vid, view in views.items()
        if any(node.get("kind") == "table" for node in view["nodes"])
    }
    for vid, view in views.items():
        for node in view["nodes"]:
            nid = node["id"]
            if node.get("kind") == "table":
                cols = node.get("cols") or []
                rows = node.get("rows") or []
                if len(cols) < 2:
                    errors.append(
                        f"{vid}/{nid}: table needs at least two columns (one per weight group)"
                    )
                if not rows:
                    errors.append(f"{vid}/{nid}: table has no rows")
                for row in rows:
                    label = row.get("label") or row.get("id") or "?"
                    ref = row.get("ref")
                    if not ref:
                        errors.append(
                            f"{vid}/{nid}/{label}: row has no ref; cite the file:line "
                            f"that decides this row's train/frozen state"
                        )
                    elif repo_root is not None:
                        path, _, line = str(ref).rpartition(":")
                        target = repo_root / path if path else None
                        if target is None or not target.exists():
                            errors.append(f"{vid}/{nid}/{label}: ref {ref!r} is not a file")
                        else:
                            total = len(
                                target.read_text(encoding="utf-8", errors="replace").splitlines()
                            )
                            if not line.isdigit() or not 1 <= int(line) <= total:
                                errors.append(
                                    f"{vid}/{nid}/{label}: ref {ref!r} points outside the file "
                                    f"({total} lines)"
                                )
                    cells = row.get("cells") or []
                    if len(cells) != len(cols):
                        errors.append(
                            f"{vid}/{nid}/{label}: {len(cells)} cells for {len(cols)} columns"
                        )
                    for cell in cells:
                        mark = cell.get("mark") if isinstance(cell, dict) else cell
                        if mark not in TABLE_MARKS:
                            errors.append(
                                f"{vid}/{nid}/{label}: unknown mark {mark!r}; "
                                f"use train|frozen|n-a"
                            )
            state = node.get("param_state")
            if state is not None:
                key = str(state).strip()
                if key not in PARAM_STATES:
                    errors.append(f"{vid}/{nid}: param_state {state!r} must be train|frozen|n-a")
                if not node.get("param_when"):
                    warnings.append(
                        f"{vid}/{nid}: param_state without param_when; say which config it "
                        f"holds for (use \"所有 config\" when it is universal)"
                    )
        tagged_here = [n for n in view["nodes"] if n.get("param_state") is not None]
        if tagged_here:
            target = view.get("param_matrix")
            if not target:
                errors.append(
                    f"{vid}: param_state tags but no param_matrix; declare the table view "
                    f"they point at (param_matrix: <view id>)"
                )
            elif target not in views:
                errors.append(f"{vid}: param_matrix {target!r} is not a view")
            elif target not in matrix_views:
                errors.append(f"{vid}: param_matrix {target!r} is not a kind: table view")
    tagged = any(
        node.get("param_state") for view in views.values() for node in view["nodes"]
    )
    if tagged and not matrix_views:
        warnings.append(
            "param_state tags exist but no kind: table view; the tag has nowhere to point"
        )
    if matrix_views and decisions.exists():
        text = decisions.read_text(encoding="utf-8", errors="replace")
        if "参数归属" not in text:
            warnings.append(
                "decisions.md has no 参数归属 section: record which weights train, on which "
                "config, and where the freeze filter lives"
            )

    # edge semantics: an edge is data flow, not "this node is a part of that
    # node" and not a shortcut to a detail page.
    for vid, view in views.items():
        by_id = {node["id"]: node for node in view["nodes"]}
        incident = set()
        for edge in view["edges"]:
            src, dst = edge.get("from"), edge.get("to")
            if src:
                incident.add(src)
            if dst:
                incident.add(dst)
            for end in (src, dst):
                node = by_id.get(end)
                if node and node.get("kind") == "table":
                    errors.append(
                        f"{vid}: edge {src!r}->{dst!r} touches table node {node['id']!r}; "
                        f"a table is evidence, not a flow stage"
                    )
                    break
                if node and node.get("kind") == "note":
                    errors.append(
                        f"{vid}: edge {src!r}->{dst!r} touches note node {node['id']!r}; "
                        f"notes are callouts, not flow stages"
                    )
                    break
            a, b = by_id.get(src), by_id.get(dst)
            if a and b and a.get("drill") and b.get("drill"):
                source_title = (a.get("title") or "").lower()
                target_title = (b.get("title") or "").lower()
                container = bool(REPEAT_RE.search(source_title)) or "block" in source_title
                internal = any(hint in target_title for hint in INTERNAL_HINTS)
                boundary = any(hint in target_title for hint in BOUNDARY_HINTS) or "block" in target_title
                if container and internal and not boundary:
                    errors.append(
                        f"{vid}: edge {a['id']!r}->{b['id']!r} looks like containment: "
                        f"{a['id']!r} is a repeated/container node and {b['id']!r} looks "
                        f"internal; an edge means data flow — use a kind: note callout"
                    )
        for node in view["nodes"]:
            if node.get("drill") and node["id"] not in incident and node.get("kind") != "note":
                warnings.append(
                    f"{vid}/{node['id']}: drillable node has no edges; if it is a "
                    f"callout, set kind: note"
                )
            title = (node.get("title") or "").lower()
            sub = (node.get("sub") or "").lower()
            if any(hint in title for hint in NORM_HINTS) and not any(
                stage in (title + " " + sub) for stage in STAGE_HINTS
            ):
                warnings.append(
                    f"{vid}/{node['id']}: RMSNorm/adaRMS node does not name its stage "
                    f"(pre-attention / pre-FFN / final)"
                )

    # tree / global edge endpoints
    for vid in data["tree"]:
        if vid not in views:
            errors.append(f"meta.tree: {vid!r} is not a view")
    global_nodes = set(data.get("globalIds") or data["globalNodes"])
    for link in data["globalLinks"]:
        for end in ("from", "to"):
            if link.get(end) and link[end] not in global_nodes:
                errors.append(f"global edge {end}={link[end]!r} is not a global element")

    # reachability
    reachable = {"global"}
    frontier = list(data["tree"])
    reachable.update(frontier)
    while frontier:
        vid = frontier.pop()
        for child in views.get(vid, {}).get("children", []):
            if child not in reachable:
                reachable.add(child)
                frontier.append(child)
    for vid in views:
        if vid not in data["tree"] and vid not in reachable:
            errors.append(f"{vid}: orphan view (not in meta.tree and no drill points to it)")

    # code / terminal rule
    for vid, view in views.items():
        if not view.get("source") and not view.get("code"):
            warnings.append(f"{vid}: no source or code pointer")
        if not view["children"]:
            has_code = bool(view.get("code"))
            if not has_code and not view.get("terminal"):
                errors.append(
                    f"{vid}: leaf view has no code pointer; add code: {{file,start,end}} "
                    f"or terminal: true with a reason"
                )
            elif not view.get("terminal") and not vid.startswith("op_"):
                warnings.append(f"{vid}: leaf view is not marked terminal: true")
        for node in view["nodes"]:
            if node.get("code") and not node["code"].get("text"):
                warnings.append(f"{vid}/{node['id']}: empty code snippet")

    # layout: short shape chips and overlapping boxes
    import itertools
    for vid, view in views.items():
        boxes = []
        for node in view["nodes"]:
            if node.get("shape") and node.get("h", 86) < 78:
                warnings.append(
                    f"{vid}/{node['id']}: h={node.get('h')} is too short for title+sub+shape; use >= 78"
                )
            if node.get("kind") in ("note", "panel"):
                continue
            boxes.append(
                (
                    node["id"],
                    node.get("x", 0),
                    node.get("y", 0),
                    node.get("w", 200),
                    node.get("h", 86),
                )
            )
        for (a, ax, ay, aw, ah), (b, bx, by, bw, bh) in itertools.combinations(boxes, 2):
            if ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by:
                warnings.append(f"{vid}: nodes {a} and {b} overlap")

    # layout bounds
    for vid, view in views.items():
        canvas = view["canvas"]
        for node in view["nodes"]:
            x, y = node.get("x", 0), node.get("y", 0)
            w, h = node.get("w", 200), node.get("h", 86)
            if x + w > canvas["w"] or y + h > canvas["h"]:
                warnings.append(
                    f"{vid}/{node['id']}: node ({x},{y},{w},{h}) exceeds canvas "
                    f"{canvas['w']}x{canvas['h']}"
                )

    # placeholders
    known = set(default) | {"B"}
    for preset in presets.values():
        known |= set(preset)
    for vid, view in views.items():
        known_view = known | set(view.get("vars") or {})
        for text in [view.get("title", ""), view.get("subtitle", "")]:
            for name in PLACEHOLDER.findall(text or ""):
                if name not in known_view and not name.isdigit():
                    warnings.append(f"{vid}: placeholder {{{name}}} has no preset/var")
        for node in view["nodes"]:
            for text in [node.get("title", ""), node.get("sub", "")]:
                for name in PLACEHOLDER.findall(str(text or "")):
                    if name not in known_view and not name.isdigit():
                        warnings.append(
                            f"{vid}/{node['id']}: placeholder {{{name}}} has no preset/var"
                        )

    if strict:
        errors.extend(warnings)
        warnings = []

    stats = {
        "views": len(views),
        "branches": len(data["tree"]),
        "leaves": sum(1 for v in views.values() if not v["children"]),
        "with_code": sum(1 for v in views.values() if v.get("code")),
    }
    return errors, warnings, stats


def main(argv=None):
    parser = argparse.ArgumentParser(description="Validate an architecture-explorer spec.")
    parser.add_argument("--spec", required=True)
    parser.add_argument("--repo-root", default=None)
    parser.add_argument("--strict", action="store_true", help="treat warnings as errors")
    args = parser.parse_args(argv)

    errors, warnings, stats = run(
        pathlib.Path(args.spec),
        pathlib.Path(args.repo_root) if args.repo_root else None,
        args.strict,
    )
    for warning in warnings:
        print(f"WARN  {warning}")
    for error in errors:
        print(f"ERROR {error}")
    if stats:
        print(
            f"views {stats['views']}  branches {stats['branches']}  "
            f"leaves {stats['leaves']}  with_code {stats['with_code']}"
        )
    print(f"{len(errors)} error(s), {len(warnings)} warning(s)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
