#!/usr/bin/env python3
"""Reconnaissance for an unfamiliar repository.

Produces a compact, evidence-bearing map that the architecture analysis can start
from: languages, entrypoints, top-level symbols, configs, and the largest files.

    python3 recon.py --repo /path/to/repo
    python3 recon.py --repo . --out docs/architecture/recon.md --json docs/architecture/recon.json

This script does not decide the architecture. It only removes the "where do I
start" cost; the agent still has to read the entrypoint and trace the real data
flow before writing any view.
"""
from __future__ import annotations

import argparse
import ast
import json
import pathlib
import re
import sys

SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", ".venv", "venv", "env", "__pycache__",
    "dist", "build", "target", ".next", ".nuxt", ".idea", ".vscode", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "coverage", "docs/architecture", "assets",
}
CODE_EXT = {
    ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".java", ".kt",
    ".kts", ".c", ".h", ".cc", ".cpp", ".hpp", ".cs", ".rb", ".php", ".swift",
    ".scala", ".sh", ".sql", ".vue", ".svelte",
}
CONFIG_EXT = {".yaml", ".yml", ".toml", ".json", ".ini", ".cfg", ".conf", ".env"}
BINARY_EXT = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".tiff",
    ".mp4", ".mov", ".avi", ".mkv", ".webm", ".mp3", ".wav",
    ".pdf", ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z",
    ".pt", ".pth", ".bin", ".safetensors", ".onnx", ".npy", ".npz", ".pkl",
    ".so", ".dylib", ".dll", ".a", ".o", ".woff", ".woff2", ".ttf", ".otf",
}
NAME_HINTS = {
    "main.py", "app.py", "server.py", "cli.py", "train.py", "eval.py", "infer.py",
    "index.js", "index.ts", "main.js", "main.ts", "main.go", "main.rs", "lib.rs",
    "app.ts", "app.js", "manage.py", "wsgi.py", "asgi.py",
}


def walk(repo: pathlib.Path):
    for path in repo.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(repo)
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        if rel.parts[:2] == ("docs", "architecture"):
            continue
        if path.suffix.lower() in BINARY_EXT:
            continue
        if path.stat().st_size > 2_000_000:
            continue
        yield path, rel


def py_symbols(path: pathlib.Path):
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return [], False
    symbols, has_main = [], False
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            symbols.append({"kind": "def", "name": node.name, "line": node.lineno})
            if node.name == "main":
                has_main = True
        elif isinstance(node, ast.ClassDef):
            bases = []
            for base in node.bases:
                if isinstance(base, ast.Name):
                    bases.append(base.id)
                elif isinstance(base, ast.Attribute):
                    bases.append(base.attr)
            methods = [n.name for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            symbols.append({
                "kind": "class",
                "name": node.name,
                "line": node.lineno,
                "bases": bases,
                "methods": methods[:12],
            })
        elif isinstance(node, ast.If):
            if "__main__" in ast.dump(node.test):
                has_main = True
    return symbols, has_main


JS_DEF = re.compile(
    r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(class|function|const|let)\s+([A-Za-z_$][\w$]*)",
    re.M,
)


def js_symbols(path: pathlib.Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    out = []
    for match in JS_DEF.finditer(text):
        line = text.count("\n", 0, match.start()) + 1
        out.append({"kind": match.group(1), "name": match.group(2), "line": line})
    return out[:20]


def entrypoints(repo: pathlib.Path, files):
    found = []

    def add(path, why):
        rel = str(path.relative_to(repo))
        if rel not in {x["file"] for x in found}:
            found.append({"file": rel, "why": why})

    for path, rel in files:
        if path.name in NAME_HINTS:
            add(path, "conventional entrypoint name")
        if path.suffix == ".py":
            try:
                _, has_main = py_symbols(path)
            except Exception:
                has_main = False
            if has_main:
                add(path, "if __name__ == '__main__' / def main")
        if path.suffix in (".js", ".ts") and path.name in {"index.js", "index.ts"} and len(rel.parts) <= 2:
            add(path, "package root index")
        if path.name == "Dockerfile":
            text = path.read_text(encoding="utf-8", errors="replace")
            for line in text.splitlines():
                if line.strip().upper().startswith(("CMD", "ENTRYPOINT")):
                    add(path, line.strip()[:120])
                    break
        if path.suffix == ".go":
            text = path.read_text(encoding="utf-8", errors="replace")
            if "package main" in text and "func main(" in text:
                add(path, "package main + func main")
        if path.suffix in (".java", ".kt"):
            text = path.read_text(encoding="utf-8", errors="replace")
            if "static void main" in text:
                add(path, "static void main")
    return found


def configs(repo: pathlib.Path, files):
    out = []
    for path, rel in files:
        if path.suffix.lower() in CONFIG_EXT and len(rel.parts) <= 3:
            out.append(str(rel))
    return sorted(out)[:40]


def project_scripts(repo: pathlib.Path):
    scripts = []
    pyproject = repo / "pyproject.toml"
    if pyproject.exists():
        try:
            import tomllib
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
            scripts += [f"{k} = {v}" for k, v in data.get("project", {}).get("scripts", {}).items()]
        except Exception:
            pass
    package = repo / "package.json"
    if package.exists():
        try:
            data = json.loads(package.read_text(encoding="utf-8"))
            for key in ("main", "module", "bin"):
                if isinstance(data.get(key), str):
                    scripts.append(f"{key} = {data[key]}")
            for key, value in (data.get("scripts") or {}).items():
                scripts.append(f"scripts.{key} = {value}")
        except Exception:
            pass
    cargo = repo / "Cargo.toml"
    if cargo.exists():
        try:
            import tomllib
            data = tomllib.loads(cargo.read_text(encoding="utf-8"))
            for bin_ in data.get("bin", []) or []:
                scripts.append(f"bin {bin_.get('name')} = {bin_.get('path')}")
        except Exception:
            pass
    return scripts


def render(repo: pathlib.Path, files, entry, cfg, scripts, symbols_by_file):
    stat = {}
    for path, rel in files:
        ext = path.suffix.lower() or "(none)"
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").count("\n") + 1
        except Exception:
            lines = 0
        item = stat.setdefault(ext, {"files": 0, "lines": 0})
        item["files"] += 1
        item["lines"] += lines

    ordered = sorted(stat.items(), key=lambda kv: kv[1]["lines"], reverse=True)
    total_files = sum(v["files"] for v in stat.values())
    total_lines = sum(v["lines"] for v in stat.values())

    out = [f"# Recon: {repo.name}", ""]
    out.append(f"{total_files} files · {total_lines:,} lines")
    out.append("")
    out.append("## Languages")
    out.append("")
    out.append("| ext | files | lines |")
    out.append("| --- | ---: | ---: |")
    for ext, item in ordered[:12]:
        out.append(f"| {ext} | {item['files']} | {item['lines']:,} |")
    out.append("")

    out.append("## Entrypoint candidates")
    out.append("")
    if entry:
        for item in entry:
            out.append(f"- `{item['file']}` — {item['why']}")
    else:
        out.append("- none detected; start from pyproject.toml / package.json / README")
    out.append("")

    out.append("## Declared commands")
    out.append("")
    out.extend(f"- `{s}`" for s in scripts) if scripts else out.append("- none")
    out.append("")

    out.append("## Config files")
    out.append("")
    out.extend(f"- `{c}`" for c in cfg) if cfg else out.append("- none")
    out.append("")

    out.append("## Top-level symbols")
    out.append("")
    for rel, syms in symbols_by_file.items():
        if not syms:
            continue
        out.append(f"### {rel}")
        out.append("")
        for sym in syms[:24]:
            bits = [f"{sym['kind']} `{sym['name']}` :{sym['line']}"]
            if sym.get("bases"):
                bits.append("(" + ", ".join(sym["bases"]) + ")")
            if sym.get("methods"):
                bits.append("methods: " + ", ".join(sym["methods"]))
            out.append("- " + " ".join(bits))
        out.append("")
    return "\n".join(out) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description="Repository reconnaissance.")
    parser.add_argument("--repo", default=".")
    parser.add_argument("--out", default=None, help="markdown output (default: docs/architecture/recon.md)")
    parser.add_argument("--json", default=None, help="optional JSON output")
    args = parser.parse_args(argv)

    repo = pathlib.Path(args.repo).resolve()
    files = list(walk(repo))
    entry = entrypoints(repo, files)
    cfg = configs(repo, files)
    scripts = project_scripts(repo)

    symbols_by_file = {}
    for path, rel in files:
        if path.suffix == ".py":
            syms, _ = py_symbols(path)
        elif path.suffix in (".js", ".jsx", ".ts", ".tsx"):
            syms = js_symbols(path)
        else:
            continue
        if syms:
            symbols_by_file[str(rel)] = syms

    markdown = render(repo, files, entry, cfg, scripts, symbols_by_file)
    out = pathlib.Path(args.out) if args.out else repo / "docs" / "architecture" / "recon.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(markdown, encoding="utf-8")
    print(f"wrote {out}")

    if args.json:
        payload = {
            "repo": str(repo),
            "entrypoints": entry,
            "configs": cfg,
            "scripts": scripts,
            "symbols": symbols_by_file,
        }
        jout = pathlib.Path(args.json)
        jout.parent.mkdir(parents=True, exist_ok=True)
        jout.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"wrote {jout}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
