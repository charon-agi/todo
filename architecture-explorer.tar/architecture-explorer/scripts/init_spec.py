#!/usr/bin/env python3
"""Scaffold an architecture-explorer spec inside a repository.

    python3 init_spec.py --repo /path/to/repo
    python3 init_spec.py --repo . --dir docs/architecture

Creates:

    docs/architecture/spec/meta.yaml
    docs/architecture/spec/global.yaml
    docs/architecture/spec/templates.yaml
    docs/architecture/spec/glossary.yaml
    docs/architecture/spec/branches/stage1.yaml
    docs/architecture/assets/

It refuses to overwrite existing files unless --force is passed.
"""
from __future__ import annotations

import argparse
import pathlib
import shutil
import subprocess
import sys

SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent
TEMPLATES = SKILL_DIR / "assets" / "templates"


def repo_root(path: pathlib.Path) -> pathlib.Path:
    try:
        out = subprocess.run(
            ["git", "-C", str(path), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        if out:
            return pathlib.Path(out)
    except Exception:
        pass
    return path.resolve()


def pick_sample(root: pathlib.Path):
    """Pick a small, real source file for the scaffold's code pointers."""
    exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".kt"}
    skip = {".git", "node_modules", ".venv", "venv", "dist", "build", "target", "__pycache__"}
    best = None
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in exts:
            continue
        if any(part in skip for part in path.relative_to(root).parts):
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").count("\n") + 1
        except Exception:
            continue
        if lines < 30:
            continue
        candidate = (lines, path)
        if best is None or candidate < best:
            best = candidate
    if not best:
        return None, 0
    lines, path = best
    return str(path.relative_to(root)), lines


def main(argv=None):
    parser = argparse.ArgumentParser(description="Scaffold an explorer spec.")
    parser.add_argument("--repo", default=".", help="repository path (default: cwd)")
    parser.add_argument("--dir", default="docs/architecture", help="output directory in the repo")
    parser.add_argument("--force", action="store_true", help="overwrite existing spec files")
    args = parser.parse_args(argv)

    root = repo_root(pathlib.Path(args.repo))
    out = root / args.dir
    spec = out / "spec"
    branches = spec / "branches"
    assets = out / "assets"
    branches.mkdir(parents=True, exist_ok=True)
    assets.mkdir(parents=True, exist_ok=True)

    name = root.name

    # Point the scaffold at a real file so init -> check -> build works even
    # before the agent replaces the demo stages.
    sample, sample_lines = pick_sample(root)
    branch_text = (TEMPLATES / "branch.yaml").read_text(encoding="utf-8")
    global_text = (TEMPLATES / "global.yaml").read_text(encoding="utf-8")
    if sample:
        branch_text = branch_text.replace("path/to/file.py", sample)
        branch_text = branch_text.replace("start: 1, end: 40", f"start: 1, end: {min(40, sample_lines)}")
        branch_text = branch_text.replace("line: 20", f"line: {min(20, sample_lines)}")
        branch_text = branch_text.replace(
            "start: 20, end: 28", f"start: {min(20, sample_lines)}, end: {min(28, sample_lines)}"
        )
        global_text = global_text.replace("path/to/entry.py:12", f"{sample}:1")

    plan = {
        "meta.yaml": (TEMPLATES / "meta.yaml").read_text(encoding="utf-8"),
        "global.yaml": global_text,
        "templates.yaml": (TEMPLATES / "templates.yaml").read_text(encoding="utf-8"),
        "glossary.yaml": (TEMPLATES / "glossary.yaml").read_text(encoding="utf-8"),
        "branches/stage1.yaml": branch_text,
        "decisions.md": (TEMPLATES / "decisions.md").read_text(encoding="utf-8"),
    }

    written, skipped = [], []
    for rel, text in plan.items():
        path = spec / rel
        if path.exists() and not args.force:
            skipped.append(str(path))
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text.replace("REPO_NAME", name), encoding="utf-8")
        written.append(str(path))

    for line in written:
        print(f"wrote {line}")
    for line in skipped:
        print(f"kept  {line}")
    print()
    print("next:")
    print(f"  1. grill the exploration plan, then fill {spec/'decisions.md'}")
    print(f"  2. replace the placeholder stages in {spec/'global.yaml'}")
    print(f"  3. write one file per branch in {branches}")
    print(f"  4. replace the demo terms in {spec/'glossary.yaml'} with this repo's own vocabulary")
    print(f"  5. python3 {SKILL_DIR/'scripts'/'check.py'} --spec {spec} --repo-root {root}")
    print(f"  6. python3 {SKILL_DIR/'scripts'/'build.py'} --spec {spec} --out {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
