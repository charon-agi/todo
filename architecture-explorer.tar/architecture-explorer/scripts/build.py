#!/usr/bin/env python3
"""Build an interactive architecture explorer and a static architecture figure.

The input is a spec directory (default: <repo>/docs/architecture/spec) with:

    meta.yaml          optional: title, repo name, canvas, tree order, symbols
    presets.yaml       optional: named hyper-parameter sets (alias: _presets.yaml)
    templates.yaml     optional: reusable views (alias: _templates.yaml)
    glossary.yaml      optional: terms + plain-language explanations
    branches/*.yaml    one or more files, each with a "views" list
    global.yaml        global view as data: panels, nodes, edges, legend, caption
      OR
    global_figure.html + global_nodes.yaml + global_links.yaml
                       legacy raw-markup global view (supported for DreamZero)

Outputs (default: <repo>/docs/architecture):

    explorer.html       interactive: breadcrumbs, sidebar, inspector, presets
    architecture.html   static global figure, links drawn on load

Usage:
    python3 build.py --spec docs/architecture/spec --out docs/architecture
    python3 build.py --spec docs/architecture/spec --out docs/architecture --no-static
"""
from __future__ import annotations

import argparse
import ast
import html
import json
import pathlib
import re
import subprocess
import sys
import textwrap

import yaml

SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent
RUNTIME = SKILL_DIR / "assets" / "runtime"

ALLOWED_OPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod)


# ---------------------------------------------------------------------------
# loading
# ---------------------------------------------------------------------------


def load_yaml(path: pathlib.Path):
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def pick(base: pathlib.Path, *names: str):
    for name in names:
        path = base / name
        if path.exists():
            return path
    return None


def normalize_symbols(raw):
    """Normalise a letter -> explanation map.

    Accepts either a string (the detailed meaning) or an object with
    name/zh/detail. Letters are kept verbatim: case is meaningful in einsum.
    """
    out = {}
    if not isinstance(raw, dict):
        return out
    for key, value in raw.items():
        letter = str(key).strip()
        if not letter:
            continue
        if isinstance(value, dict):
            out[letter] = {
                "name": str(value.get("name") or ""),
                "zh": str(value.get("zh") or ""),
                "detail": str(
                    value.get("detail") or value.get("meaning") or value.get("desc") or ""
                ),
            }
        else:
            out[letter] = {"name": "", "zh": "", "detail": str(value or "")}
    return out


def load_glossary(spec_dir: pathlib.Path):
    """Load the optional plain-language layer.

    Terms are deliberately plain data: the builder only normalises defaults so
    the runtime can link aliases without knowing anything about the repository.
    """
    path = pick(spec_dir, "glossary.yaml", "glossary.yml")
    if not path:
        return {"title": "名词解释", "subtitle": "", "intro": [], "categories": [], "terms": []}
    doc = load_yaml(path) or {}
    categories = [str(c) for c in (doc.get("categories") or [])]
    terms = []
    for index, raw in enumerate(doc.get("terms") or []):
        if not isinstance(raw, dict) or not str(raw.get("term") or "").strip():
            continue
        term = str(raw["term"]).strip()
        gid = str(raw.get("id") or re.sub(r"[^a-z0-9]+", "-", term.lower()).strip("-") or f"term-{index + 1}")
        aliases = raw.get("aliases") or raw.get("alias") or [term]
        if isinstance(aliases, str):
            aliases = [aliases]
        category = str(raw.get("category") or "其他")
        if category not in categories:
            categories.append(category)
        terms.append(
            {
                "id": gid,
                "term": term,
                "zh": str(raw.get("zh") or ""),
                "category": category,
                "core": bool(raw.get("core")),
                "plain": str(raw.get("plain") or ""),
                "detail": str(raw.get("detail") or ""),
                "analogy": str(raw.get("analogy") or raw.get("ana") or ""),
                "aliases": [str(a) for a in aliases if str(a).strip()],
                "views": [str(v) for v in (raw.get("views") or raw.get("where") or [])],
            }
        )
    return {
        "title": str(doc.get("title") or "名词解释"),
        "subtitle": str(doc.get("subtitle") or "先懂这些词，再看图。"),
        "intro": doc.get("intro") or [],
        "categories": categories,
        "terms": terms,
    }


def detect_repo_root(spec_dir: pathlib.Path) -> pathlib.Path:
    try:
        out = subprocess.run(
            ["git", "-C", str(spec_dir), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        if out:
            return pathlib.Path(out)
    except Exception:
        pass
    markers = ("pyproject.toml", "package.json", "Cargo.toml", "go.mod", "setup.py", ".git")
    for parent in [spec_dir, *spec_dir.parents]:
        if any((parent / marker).exists() for marker in markers):
            return parent
    parents = list(spec_dir.parents)
    if len(parents) >= 3:
        return parents[2]
    return parents[-1] if parents else spec_dir


def norm_ref(ref, default_line=1):
    """Accept {file, start/end/line} or the string 'path:line'."""
    if not ref:
        return None
    if isinstance(ref, str):
        match = re.match(r"^(.*?):(\d+)(?:-(\d+))?$", ref.strip())
        if match:
            start = int(match.group(2))
            end = int(match.group(3) or start)
            return {"file": match.group(1), "start": start, "end": end, "line": start}
        return {"file": ref, "start": default_line, "end": default_line, "line": default_line}
    start = int(ref.get("start", ref.get("line", default_line)))
    end = int(ref.get("end", start))
    return {"file": ref["file"], "start": start, "end": end, "line": start}


def read_code(ref, repo_root: pathlib.Path):
    ref = norm_ref(ref)
    if not ref:
        return None
    path = (repo_root / ref["file"]).resolve()
    if not path.exists():
        raise FileNotFoundError(f"code reference not found: {ref['file']} (from {repo_root})")
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(1, ref["start"])
    end = min(len(lines), ref["end"])
    if start > len(lines):
        raise ValueError(f"line {start} is past end of {ref['file']} ({len(lines)} lines)")
    snippet = textwrap.dedent("\n".join(lines[start - 1 : end])).rstrip()
    return {"file": ref["file"], "start": start, "end": end, "text": snippet}


def _eval_num(expr, ctx):
    if isinstance(expr, (int, float)):
        return expr

    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.Name):
            if node.id not in ctx:
                raise KeyError(f"unknown key {node.id!r} in calc expression {expr!r}")
            return visit(ast.parse(str(ctx[node.id])).body[0].value)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ALLOWED_OPS):
            left, right = visit(node.left), visit(node.right)
            return {
                ast.Add: left + right,
                ast.Sub: left - right,
                ast.Mult: left * right,
                ast.Div: left / right,
                ast.FloorDiv: left // right,
                ast.Mod: left % right,
            }[type(node.op)]
        raise ValueError(f"unsupported calc expression: {expr!r}")

    return int(visit(ast.parse(str(expr), mode="eval")))


def resolve_vars(vars_map, preset):
    ctx = dict(preset or {})
    out = {}
    for key, value in (vars_map or {}).items():
        out[key] = _eval_num(value, ctx) if isinstance(value, (int, float, str)) else value
    return out


def calc_params(calc, ctx):
    """Parameter counts for common layers. Extend here, not in the branch files."""
    kind = calc["type"]
    if kind == "cs_linear":
        cats = _eval_num(calc["cats"], ctx)
        din = _eval_num(calc["din"], ctx)
        dout = _eval_num(calc["dout"], ctx)
        return cats * (din * dout + dout)
    if kind == "linear_pair":
        d1 = _eval_num(calc["d1"], ctx)
        h = _eval_num(calc["h"], ctx)
        return d1 * h + h + h * d1 + d1
    if kind == "linear":
        din = _eval_num(calc["din"], ctx)
        dout = _eval_num(calc["dout"], ctx)
        return din * dout + dout
    if kind == "linear_pair_gate":
        d1 = _eval_num(calc["d1"], ctx)
        h = _eval_num(calc["h"], ctx)
        return 3 * d1 * h
    if kind == "conv2d":
        cin = _eval_num(calc["cin"], ctx)
        cout = _eval_num(calc["cout"], ctx)
        k = _eval_num(calc["k"], ctx)
        return cout * (cin * k * k) + cout
    if kind == "conv3d":
        cin = _eval_num(calc["cin"], ctx)
        cout = _eval_num(calc["cout"], ctx)
        kt = _eval_num(calc.get("kt", 1), ctx)
        kh = _eval_num(calc.get("kh", 1), ctx)
        kw = _eval_num(calc.get("kw", 1), ctx)
        return cout * (cin * kt * kh * kw) + cout
    if kind == "embedding":
        return _eval_num(calc["vocab"], ctx) * _eval_num(calc["dim"], ctx)
    if kind == "expr":
        return _eval_num(calc["expr"], ctx)
    raise ValueError(f"unknown calc type {kind!r}")


def expand_views(templates, branch_views):
    """Resolve extends: templates provide the base view, instances override keys."""
    template_map = {v["id"]: v for v in templates}
    views = {}
    for view in branch_views:
        views[view["id"]] = view
    for view in templates:
        if not view.get("template"):
            views.setdefault(view["id"], view)
    for vid, view in list(views.items()):
        parent_id = view.get("extends")
        if not parent_id:
            continue
        if parent_id not in template_map:
            raise KeyError(f"{vid}: extends unknown template {parent_id!r}")
        base = json.loads(json.dumps(template_map[parent_id]))
        base.update({k: v for k, v in view.items() if k != "extends"})
        merged = dict(template_map[parent_id].get("vars") or {})
        merged.update(view.get("vars") or {})
        base["vars"] = merged
        base["id"] = vid
        views[vid] = base
    return views


# ---------------------------------------------------------------------------
# global view
# ---------------------------------------------------------------------------


def esc(value):
    return html.escape(str(value), quote=True)


def style_of(node):
    bits = [f"left:{node.get('x', 0)}px", f"top:{node.get('y', 0)}px"]
    if node.get("w"):
        bits.append(f"width:{node['w']}px")
    if node.get("h"):
        bits.append(f"height:{node['h']}px")
    return ";".join(bits)


def global_node_html(node):
    kind = node.get("kind", "card")
    accent = node.get("accent", "neu")
    style = style_of(node)
    ident = f' id="{esc(node["id"])}"' if node.get("id") else ""
    drill = f' data-drill="{esc(node["drill"])}"' if node.get("drill") else ""
    if kind == "panel":
        label = esc(node.get("label", ""))
        fill = f'background:{node["fill"]};' if node.get("fill") else ""
        return (
            f'<div class="pan" id="{esc(node["id"])}" '
            f'style="{style};{fill}"><div class="plabel">{label}</div></div>'
        )
    if kind == "html":
        return node.get("html", "")
    if kind == "enc":
        sub = f'<div class="ed">{esc(node.get("sub", ""))}</div>' if node.get("sub") else ""
        return (
            f'<div class="enc ac-{accent}"{ident}{drill} style="{style}">'
            f'<div><div class="et">{esc(node.get("title", ""))}</div>{sub}</div></div>'
        )
    if kind == "strip":
        sub = f'<div class="sd">{esc(node.get("sub", ""))}</div>' if node.get("sub") else ""
        return (
            f'<div class="strip ac-{accent}"{ident}{drill} style="{style}">'
            f'<div class="st">{esc(node.get("title", ""))}</div>{sub}</div>'
        )
    if kind == "inset":
        return (
            f'<div class="inset"{ident} style="{style}">'
            f'<div class="il">{esc(node.get("title", ""))}</div>{node.get("html", "")}</div>'
        )
    # card / note
    cls = "n note" if kind == "note" else "n"
    params = f'<div class="np">{esc(node["params"])}</div>' if node.get("params") else ""
    sub = f'<div class="nd">{esc(node.get("sub", ""))}</div>' if node.get("sub") else ""
    shape = f'<div class="ns">{esc(node["shape"])}</div>' if node.get("shape") else ""
    extra = node.get("html", "")
    pad = ";padding:0" if node.get("flush") else ""
    return (
        f'<div class="{cls} ac-{accent}"{ident}{drill} style="{style}{pad}">'
        f'{params}<div class="nt">{esc(node.get("title", ""))}</div>{sub}{shape}{extra}</div>'
    )


def legend_html(legend):
    if not legend:
        return ""
    items = []
    for item in legend:
        if item.get("type") == "encoder":
            chip = '<span class="trchip"></span>'
        elif item.get("type") == "dash":
            chip = '<span class="lchip"></span>'
        else:
            chip = f'<span class="chip" style="background:{item.get("color", "#8798ab")}"></span>'
        items.append(f'<span class="lgi">{chip}{esc(item.get("label", ""))}</span>')
    return '<div class="legend">' + "".join(items) + "</div>"


def footnote_html(footnote):
    if not footnote:
        return ""
    columns = footnote if isinstance(footnote, list) else footnote.get("columns", [])
    if not columns:
        return ""
    parts = []
    for i, column in enumerate(columns):
        if i:
            parts.append('<div class="vsep"></div>')
        width = f' style="width:{column["width"]}px"' if column.get("width") else ""
        parts.append(
            f'<div class="fcol"{width}><b>{esc(column.get("title", ""))}</b><br>'
            f'<span class="mono">{column.get("text", "")}</span></div>'
        )
    return '<div class="footnote">' + "".join(parts) + "</div>"


def caption_html(caption):
    return f'<div class="caption">{caption}</div>' if caption else ""


def render_global(global_doc, legacy_html=None):
    if legacy_html is not None:
        return legacy_html
    chunks = []
    if global_doc.get("title"):
        chunks.append(f'<div class="ftitle">{esc(global_doc["title"])}</div>')
    chunks.append(legend_html(global_doc.get("legend")))
    for node in global_doc.get("panels", []):
        chunks.append(global_node_html({**node, "kind": "panel"}))
    for node in global_doc.get("nodes", []):
        chunks.append(global_node_html(node))
    chunks.append(footnote_html(global_doc.get("footnote")))
    chunks.append(caption_html(global_doc.get("caption")))
    chunks.append('<svg class="links"></svg>')
    return "\n".join(chunks)


# ---------------------------------------------------------------------------
# spec loading
# ---------------------------------------------------------------------------


def load_spec(spec_dir: pathlib.Path, repo_root: pathlib.Path | None = None):
    spec_dir = spec_dir.resolve()
    if not spec_dir.is_dir():
        raise NotADirectoryError(f"spec directory not found: {spec_dir}")
    repo_root = (repo_root or detect_repo_root(spec_dir)).resolve()

    meta_path = pick(spec_dir, "meta.yaml", "meta.yml")
    meta = load_yaml(meta_path) if meta_path else {}

    presets_path = pick(spec_dir, "presets.yaml", "_presets.yaml")
    if presets_path:
        presets_doc = load_yaml(presets_path)
        presets = presets_doc.get("presets", {})
        default_preset = presets_doc.get("default") or next(iter(presets), None)
    else:
        presets, default_preset = {}, None

    templates_path = pick(spec_dir, "templates.yaml", "_templates.yaml")
    templates = load_yaml(templates_path).get("views", []) if templates_path else []

    glossary = load_glossary(spec_dir)

    branch_views = []
    for path in sorted((spec_dir / "branches").glob("*.yaml")):
        branch_views.extend(load_yaml(path).get("views", []))
    if not branch_views:
        raise ValueError(f"no views found in {spec_dir / 'branches'}")

    views = expand_views(templates, branch_views)

    global_path = pick(spec_dir, "global.yaml", "global.yml")
    legacy_html_path = pick(spec_dir, "global_figure.html")
    global_doc = load_yaml(global_path) if global_path else {}
    if not global_path and not legacy_html_path:
        raise FileNotFoundError(
            f"need {spec_dir/'global.yaml'} or {spec_dir/'global_figure.html'}"
        )

    symbols = normalize_symbols({**(meta.get("symbols") or {}), **(global_doc.get("symbols") or {})})

    canvas = global_doc.get("canvas") or meta.get("canvas") or {"w": 1600, "h": 900}
    default_view_canvas = meta.get("view_canvas", {"w": 1600, "h": 900})

    out_views = {}
    for vid, view in views.items():
        data = {
            "id": vid,
            "title": view["title"],
            "subtitle": view.get("subtitle", ""),
            "parent": view.get("parent", "global"),
            "style": view.get("style", "paper"),
            "canvas": view.get("canvas", default_view_canvas),
            "summary": view.get("summary", ""),
            "plain": view.get("plain", ""),
            "plain_terms": view.get("plain_terms") or [],
            "param_matrix": view.get("param_matrix"),
            "symbols": normalize_symbols(view.get("symbols")),
            "vars": view.get("vars") or {},
            "inherits": view.get("inherits"),
            "accent": view.get("accent"),
            "terminal": bool(view.get("terminal")),
            "source": norm_ref(view.get("source")),
            "nodes": [],
            "edges": view.get("edges") or [],
            "code": read_code(view.get("code"), repo_root) if view.get("code") else None,
            "children": [],
        }
        for node in view.get("nodes", []):
            item = {k: v for k, v in node.items() if k != "calc"}
            if node.get("calc"):
                item["params"] = {
                    name: calc_params(node["calc"], {**preset, **resolve_vars(view.get("vars"), preset)})
                    for name, preset in presets.items()
                }
            if node.get("code"):
                item["code"] = read_code(node["code"], repo_root)
            if node.get("source"):
                item["source"] = norm_ref(node["source"])
            data["nodes"].append(item)
        out_views[vid] = data

    for vid, view in out_views.items():
        seen = set()
        for node in view["nodes"]:
            target = node.get("drill")
            if target and target not in seen:
                seen.add(target)
                view["children"].append(target)

    tree = meta.get("tree")
    if not tree:
        tree = [vid for vid, v in out_views.items() if v["parent"] == "global"]

    default_accents = {
        "text": "#6d5fc7",
        "video": "#3f7fc4",
        "image": "#3f7fc4",
        "action": "#cf7f34",
        "state": "#2f9e6f",
        "neu": "#8798ab",
    }
    palette = {**default_accents, **(meta.get("accents") or {})}
    accents = {}

    def dominant_accent(view):
        counts = {}
        for node in view.get("nodes", []):
            name = node.get("accent")
            if name and name not in ("neu", "neutral", "none"):
                counts[name] = counts.get(name, 0) + 1
        if not counts:
            return None
        return max(counts, key=counts.get)

    def accent_of(vid, depth=0):
        if vid in accents:
            return accents[vid]
        view = out_views.get(vid)
        if not view or depth > 20:
            return palette["neu"]
        accent = view.get("accent")
        if not accent and view.get("parent") and view["parent"] != "global":
            accent = accent_of(view["parent"], depth + 1)
        if not accent:
            accent = dominant_accent(view) or "neu"
        if not str(accent).startswith("#"):
            accent = palette.get(accent, palette["neu"])
        accents[vid] = accent
        return accent

    for vid in out_views:
        accent_of(vid)

    if legacy_html_path:
        global_html = legacy_html_path.read_text(encoding="utf-8")
        global_nodes_path = pick(spec_dir, "global_nodes.yaml")
        global_nodes = load_yaml(global_nodes_path) if global_nodes_path else {}
        global_links_path = pick(spec_dir, "global_links.yaml")
        global_links = (
            (load_yaml(global_links_path) or {}).get("links", [])
            if global_links_path
            else global_doc.get("edges", [])
        )
    else:
        global_html = render_global(global_doc)
        global_nodes = {
            n["id"]: {k: n.get(k) for k in ("title", "sub", "shape", "note", "term") if n.get(k)}
            for n in global_doc.get("nodes", [])
            if n.get("id") and n.get("kind") not in ("panel", "html")
        }
        global_links = global_doc.get("edges", []) or []

    title = meta.get("title") or global_doc.get("title") or "Architecture Explorer"
    subtitle = meta.get("subtitle") or global_doc.get("subtitle") or ""
    stats = f"{len(out_views)} views · {len(tree)} branches"
    meta = {
        **meta,
        "title": title,
        "subtitle": subtitle,
        "stats": stats,
        "repo": meta.get("repo", repo_root.name),
    }

    global_ids = sorted(set(re.findall(r'id="([^"]+)"', global_html)))

    data = {
        "meta": meta,
        "presets": presets,
        "defaultPreset": default_preset,
        "views": out_views,
        "glossary": glossary,
        "symbols": symbols,
        "globalNodes": global_nodes,
        "globalIds": global_ids,
        "globalLinks": global_links,
        "viewAccents": accents,
        "tree": tree,
        "global": {
            "id": "global",
            "title": title,
            "subtitle": subtitle or "全局视图 · 点击带下划线的模块进入局部视图",
            "parent": None,
            "style": "paper",
            "canvas": canvas,
            "summary": meta.get("summary", "全局结构。带下划线的模块可以点开。"),
            "plain": global_doc.get("plain") or meta.get("plain") or "",
            "plain_terms": global_doc.get("plain_terms") or meta.get("plain_terms") or [],
            "symbols": normalize_symbols(global_doc.get("symbols")),
            "source": norm_ref(meta.get("source")),
            "nodes": [],
            "edges": [],
            "code": None,
            "children": tree,
            "special": "figure",
        },
    }
    return data, global_html


# ---------------------------------------------------------------------------
# html
# ---------------------------------------------------------------------------

STATIC_LINKS_JS = """
const LINKS = __LINKS__;
function rectOf(id){
  const el=document.getElementById(id), r=el.getBoundingClientRect(), s=document.querySelector('.fig').getBoundingClientRect();
  return {left:r.left-s.left, top:r.top-s.top, right:r.right-s.left, bottom:r.bottom-s.top};
}
function routeStatic(a,b){
  const acx=(a.left+a.right)/2, acy=(a.top+a.bottom)/2;
  const cl=(v,lo,hi)=>Math.min(Math.max(v,lo),hi);
  const hGap = b.left>=a.right ? b.left-a.right : a.left>=b.right ? a.left-b.right : -1;
  const vGap = b.top>=a.bottom ? b.top-a.bottom : a.top>=b.bottom ? a.top-b.bottom : -1;
  if(hGap>=0 && (vGap<0 || hGap>=vGap)){
    const right=b.left>=a.right;
    const x1=right?a.right:a.left, x2=right?b.left:b.right;
    const y1=acy, y2=cl(acy,b.top+12,b.bottom-12);
    if(Math.abs(y1-y2)<1.5) return [[x1,y1],[x2,y2]];
    const mid=(x1+x2)/2;
    return [[x1,y1],[mid,y1],[mid,y2],[x2,y2]];
  }
  if(vGap>=0){
    const down=b.top>=a.bottom;
    const y1=down?a.bottom:a.top, y2=down?b.top:b.bottom;
    const x1=cl(acx,a.left+12,a.right-12), x2=cl(acx,b.left+12,b.right-12);
    if(Math.abs(x1-x2)<1.5) return [[x1,y1],[x2,y2]];
    const mid=(y1+y2)/2;
    return [[x1,y1],[x1,mid],[x2,mid],[x2,y2]];
  }
  return [[acx,acy],[(b.left+b.right)/2,(b.top+b.bottom)/2]];
}
const svg=document.querySelector('svg.links');
let body='<defs><marker id="ah" markerUnits="userSpaceOnUse" markerWidth="9" markerHeight="9" refX="9" refY="4.5" orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="context-stroke"/></marker></defs>';
for(const L of LINKS){
  const c=L.c||'#93a3b5', dash=L.dash?('stroke-dasharray="'+L.dash+'"'):'';
  if(L.d){
    let p='M'+L.d[0]+','+L.d[1];
    for(let i=2;i<L.d.length;i+=2) p+=' L'+L.d[i]+','+L.d[i+1];
    body+='<path d="'+p+'" fill="none" stroke="'+c+'" stroke-width="2" '+dash+' marker-end="url(#ah)"/>';
  }else{
    const A=rectOf(L.f), B=rectOf(L.t);
    const pts=routeStatic(A,B);
    let d='M'+pts[0][0]+','+pts[0][1];
    for(let k=1;k<pts.length;k++) d+=' L'+pts[k][0]+','+pts[k][1];
    body+='<path d="'+d+'" fill="none" stroke="'+c+'" stroke-width="2" '+dash+' marker-end="url(#ah)"/>';
  }
}
svg.innerHTML=body;
"""


def links_for_js(links):
    out = []
    for link in links:
        if "d" in link:
            out.append({"d": link["d"], "dash": link.get("dash"), "c": link.get("c")})
        else:
            out.append({"f": link["from"], "t": link["to"], "c": link.get("c"), "dash": link.get("dash")})
    return out


def build(spec_dir, out_dir, repo_root=None, static_name="architecture.html"):
    data, global_html = load_spec(spec_dir, repo_root=repo_root)
    out_dir = pathlib.Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    figure_css = (RUNTIME / "figure.css").read_text(encoding="utf-8")
    explorer_css = (RUNTIME / "explorer.css").read_text(encoding="utf-8")
    explorer_js = (RUNTIME / "explorer.js").read_text(encoding="utf-8")
    canvas = data["global"]["canvas"]

    glossary = data["glossary"]
    glossary_title = esc(glossary.get("title") or "名词解释")
    glossary_sub = esc(glossary.get("subtitle") or "")
    glossary_intro = ""
    for item in glossary.get("intro") or []:
        if isinstance(item, dict):
            glossary_intro += (
                f'<div><b>{esc(item.get("term", ""))}</b>'
                f'<span>{esc(item.get("tag", ""))}</span>{esc(item.get("text", ""))}</div>'
            )
    glossary_intro = f'<div class="gm-intro">{glossary_intro}</div>' if glossary_intro else ""

    static_html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{esc(data['meta']['title'])}</title>
<style>
{figure_css}</style>
</head>
<body>
<div class="fig" style="width:{canvas['w']}px;height:{canvas['h']}px">
{global_html}</div>
<script>{STATIC_LINKS_JS.replace("__LINKS__", json.dumps(links_for_js(data['globalLinks']), ensure_ascii=False))}</script>
</body>
</html>
"""

    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    explorer_html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{esc(data['meta']['title'])}</title>
<style>
{figure_css}
{explorer_css}</style>
</head>
<body>
<header id="topbar">
  <div id="crumbs" class="crumbs"></div>
  <div class="tools">
    <span id="stats" class="stats"></span>
    <label class="tool">preset
      <select id="preset"></select>
    </label>
    <button id="sym" class="toggle" title="在实数与符号 shape 之间切换">Symbolic</button>
    <button id="glossaryBtn" title="打开名词解释（G）">名词解释</button>
    <button id="symbolsBtn" title="符号说明（S）" style="display:none">符号</button>
    <button id="info" title="本层说明">说明</button>
    <span class="sep"></span>
    <button id="zoomOut" title="缩小">−</button>
    <button id="zoomIn" title="放大">＋</button>
    <button id="fit" title="适应窗口">Fit</button>
    <button id="one" title="原始像素">1:1</button>
  </div>
</header>

<div id="plainbar" class="hidden">
  <span class="pb-k">人话</span>
  <div class="pb-t" id="pbText"></div>
  <div class="pb-chips" id="pbChips"></div>
  <span class="pb-hint">带 ? 的词可点</span>
</div>
<div id="tip"></div>

<div id="glossary" class="overlay hidden" role="dialog" aria-modal="true" aria-label="{glossary_title}">
  <div class="ov-bg" data-close-glossary></div>
  <div class="ov-panel">
    <div class="ov-head">
      <button class="ov-close" data-close-glossary aria-label="关闭">×</button>
      <h2>{glossary_title}</h2>
      <div class="sub">{glossary_sub}</div>
      <div class="gm-tools">
        <input id="gsearch" type="search" placeholder="搜索术语 / 中文 / 解释里的词…" autocomplete="off">
        <span class="gm-count" id="gcount"></span>
      </div>
      {glossary_intro}
    </div>
    <div class="gm-body" id="gbody"></div>
  </div>
</div>

<div id="symbols" class="overlay hidden" role="dialog" aria-modal="true" aria-label="符号说明">
  <div class="ov-bg" data-close-symbols></div>
  <div class="ov-panel sympanel">
    <div class="ov-head">
      <button class="ov-close" data-close-symbols aria-label="关闭">×</button>
      <h2>符号说明</h2>
      <div class="sub" id="symSub"></div>
    </div>
    <div class="gm-body">
      <table class="symtable">
        <thead><tr><th>符号</th><th>名称</th><th>详细含义</th></tr></thead>
        <tbody id="symBody"></tbody>
      </table>
    </div>
  </div>
</div>

<aside id="sidebar"></aside>
<main id="stagewrap">
  <div id="stage"></div>
</main>
<aside id="inspector" class="hidden">
  <button id="closeInspector" title="关闭">×</button>
  <div id="inspectorBody"></div>
</aside>
<template id="global-figure">
{global_html}</template>
<script>const DATA = {payload};</script>
<script>{explorer_js}</script>
</body>
</html>
"""

    explorer_path = out_dir / "explorer.html"
    explorer_path.write_text(explorer_html, encoding="utf-8")
    static_path = out_dir / static_name if static_name else None
    if static_path:
        static_path.write_text(static_html, encoding="utf-8")

    return {
        "explorer": str(explorer_path),
        "static": str(static_path) if static_path else None,
        "views": len(data["views"]),
        "branches": len(data["tree"]),
        "data": data,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Build an architecture explorer from a YAML spec.")
    parser.add_argument("--spec", required=True, help="spec directory")
    parser.add_argument("--out", default=None, help="output directory (default: spec parent)")
    parser.add_argument("--repo-root", default=None, help="repository root for code refs")
    parser.add_argument("--static-name", default="architecture.html")
    parser.add_argument("--no-static", action="store_true")
    args = parser.parse_args(argv)

    spec_dir = pathlib.Path(args.spec)
    out_dir = pathlib.Path(args.out) if args.out else spec_dir.parent
    result = build(
        spec_dir,
        out_dir,
        repo_root=pathlib.Path(args.repo_root) if args.repo_root else None,
        static_name=None if args.no_static else args.static_name,
    )
    print(f"wrote {result['explorer']}")
    if result["static"]:
        print(f"wrote {result['static']}")
    print(f"views: {result['views']}  branches: {result['branches']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
