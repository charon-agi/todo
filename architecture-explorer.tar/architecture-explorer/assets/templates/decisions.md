# Exploration decisions

> Filled during the grill (see `references/grilling.md`). This is the contract
> for what the explorer covers. Replace every placeholder before building.

## Scope
- Runtime path: TODO (e.g. inference only)
- In scope: TODO
- Out of scope: TODO (tests, vendored code, training, infra, ...)

## Structure
- Branch cut: TODO (data family / pipeline stage / deployable / extension point)
- Branch list: TODO
- Terminal floor: TODO (framework op / SQL / HTTP / IR node / syscall)
- Depth allocation: TODO (which paths go to the primitive, which stop at a map)
- View budget: TODO (rough number)

## Evidence
- Primary: code at `file:line`
- Secondary: TODO (configs / schemas / generated code / tests)
- Generated or vendored code: TODO (cite / exclude / mark terminal_reason)
- Runtime-assembled behavior: TODO (the concrete registration you will trace)

## Output
- Audience: TODO
- Language: TODO
- Visual style: paper for modules, graph for operators
- Output: `docs/architecture/explorer.html` + `architecture.html`
