/* Architecture Explorer — data-driven renderer (no framework, no deps). */
(function () {
  "use strict";

  const P = DATA.presets || {};
  const G = DATA.global;
  const V = DATA.views;

  const state = {
    preset: DATA.defaultPreset || Object.keys(P)[0] || null,
    symbolic: false,
    stack: ["global"],
    zoom: 1,
    pan: { x: 0, y: 0 },
    selected: null,
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const stage = $("#stage");
  const wrap = $("#stagewrap");
  const inspector = $("#inspector");
  const inspectorBody = $("#inspectorBody");

  /* ------------------------------------------------------------------ */
  /* text helpers                                                        */
  /* ------------------------------------------------------------------ */

  function resolveVars(vars, preset) {
    const out = {};
    for (const [k, v] of Object.entries(vars || {})) {
      if (typeof v === "number") {
        out[k] = v;
        continue;
      }
      try {
        const keys = Object.keys(preset);
        const vals = keys.map((key) => preset[key]);
        // eslint-disable-next-line no-new-func
        out[k] = Function(...keys, "return (" + v + ")")(...vals);
      } catch (e) {
        out[k] = v;
      }
    }
    return out;
  }

  function ctxFor(v) {
    const preset = P[state.preset] || {};
    let ctx = Object.assign({}, preset, resolveVars(v.vars, preset));
    if (v && v.inherits === "stack") {
      const i = state.stack.indexOf(v.id);
      const prevId = i > 0 ? state.stack[i - 1] : null;
      if (prevId && view(prevId) && view(prevId) !== v) {
        ctx = Object.assign(ctx, ctxFor(view(prevId)));
      }
    }
    return ctx;
  }

  function subst(str, ctx) {
    if (str === undefined || str === null) return "";
    return String(str).replace(/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/g, (m, key) =>
      ctx[key] !== undefined ? ctx[key] : m
    );
  }

  function fmtParams(n) {
    if (!n) return "";
    if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
    if (n >= 1e3) return Math.round(n / 1e3) + "K";
    return String(n);
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function codeHtml(code) {
    if (!code) return "";
    const lines = code.text.split("\n");
    const body = lines
      .map((line) => '<span class="ln">' + esc(line) + "</span>")
      .join("");
    return (
      '<div class="sec">源码 ' +
      esc(code.file.split("/").pop()) +
      " : " +
      code.start +
      "–" +
      code.end +
      '</div><pre><code>' +
      body +
      "</code></pre>"
    );
  }

  /* ------------------------------------------------------------------ */
  /* beginner layer: terms and plain-language explanations               */
  /* ------------------------------------------------------------------ */

  const GLOSSARY_META = DATA.glossary || {};
  const GLOSSARY = GLOSSARY_META.terms || [];
  const HAS_GLOSSARY = GLOSSARY.length > 0;
  const CATS = (GLOSSARY_META.categories || []).slice();
  for (const g of GLOSSARY) {
    const c = g.category || "其他";
    if (CATS.indexOf(c) === -1) CATS.push(c);
  }

  const TERM_BY_ID = Object.create(null);
  for (const g of GLOSSARY) TERM_BY_ID[g.id] = g;

  /* alias -> id, longest first so "prefix tokens" beats "token" */
  const ALIAS = [];
  for (const g of GLOSSARY) {
    const list = g.aliases && g.aliases.length ? g.aliases : [g.term];
    for (const a of list) ALIAS.push([String(a), g.id]);
  }
  ALIAS.sort((a, b) => b[0].length - a[0].length);
  const ALIAS_TO_ID = Object.create(null);
  for (const [a, id] of ALIAS) {
    if (!ALIAS_TO_ID[a.toLowerCase()]) ALIAS_TO_ID[a.toLowerCase()] = id;
  }
  const escapeRe = (s) => String(s).replace(/[.*+?^{}$()|[\]\\]/g, "\\$&");
  /* Lookarounds instead of \b so terms like "C++" or "x_t" still match. */
  const TERM_RE = ALIAS.length
    ? new RegExp(
        "(?<![A-Za-z0-9_])(?:" + ALIAS.map((a) => escapeRe(a[0])).join("|") + ")(?![A-Za-z0-9_])",
        "gi"
      )
    : null;
  const CN_TERMS = ALIAS.filter((a) => /[\u4e00-\u9fa5]/.test(a[0])).map((a) => escapeRe(a[0]));
  const CN_TERM_RE = CN_TERMS.length
    ? new RegExp("(" + CN_TERMS.join("|") + ")", "g")
    : null;

  function termForText(text) {
    if (!text || !TERM_RE) return null;
    const s = String(text);
    const m = s.match(TERM_RE);
    if (m) {
      for (const hit of m) {
        const id = ALIAS_TO_ID[hit.toLowerCase()];
        if (id) return id;
      }
    }
    if (CN_TERM_RE) {
      const c = s.match(CN_TERM_RE);
      if (c) {
        for (const hit of c) {
          const id = ALIAS_TO_ID[hit.toLowerCase()];
          if (id) return id;
        }
      }
    }
    return null;
  }

  /* Escape plain text and wrap up to `limit` distinct terms with a ? marker. */
  function annotate(text, limit) {
    if (text === undefined || text === null) return "";
    if (!TERM_RE) return esc(text);
    const max = limit || 2;
    const raw = String(text);
    const found = [];
    const collect = (re) => {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(raw))) {
        const id = ALIAS_TO_ID[m[0].toLowerCase()];
        if (id) found.push({ start: m.index, end: m.index + m[0].length, id: id });
        if (m.index === re.lastIndex) re.lastIndex++;
      }
    };
    collect(new RegExp(TERM_RE.source, "gi"));
    if (CN_TERM_RE) collect(new RegExp(CN_TERM_RE.source, "g"));
    found.sort((a, b) => b.end - b.start - (a.end - a.start));
    const chosen = [];
    for (const c of found) {
      if (chosen.length >= max) break;
      if (chosen.some((x) => x.id === c.id)) continue;
      if (chosen.every((x) => c.end <= x.start || c.start >= x.end)) chosen.push(c);
    }
    chosen.sort((a, b) => a.start - b.start);
    let out = "";
    let pos = 0;
    for (const c of chosen) {
      out +=
        esc(raw.slice(pos, c.start)) +
        '<span class="term" data-term="' +
        c.id +
        '">' +
        esc(raw.slice(c.start, c.end)) +
        '<sup class="q">?</sup></span>';
      pos = c.end;
    }
    return out + esc(raw.slice(pos));
  }

  function viewShort(id) {
    if (id === "global") return "全局视图";
    const v = view(id);
    return v ? subst(v.title, ctxFor(v)).split("·")[0].trim() : id;
  }

  /* ------------------------------------------------------------------ */
  /* shape symbols: B/T/K/G/H ...                                        */
  /* ------------------------------------------------------------------ */

  const GLOBAL_SYMBOLS = DATA.symbols || {};
  const EINSUM_TEST = /[A-Za-z0-9,]+(?:\s*->\s*[A-Za-z0-9,]+)/;

  function symbolsFor(id) {
    const v = view(id);
    return Object.assign({}, GLOBAL_SYMBOLS, (v && v.symbols) || {});
  }

  function symSpan(ch) {
    return '<span class="sym" data-sym="' + ch + '">' + ch + "</span>";
  }

  function collectShapeLetters(text, out) {
    if (!text) return;
    const src = String(text);
    const re = /[A-Za-z][A-Za-z0-9_]*/g;
    let m;
    while ((m = re.exec(src))) {
      const tok = m[0];
      if (tok.length === 1) {
        const before = m.index ? src[m.index - 1] : "";
        const after = m.index + tok.length < src.length ? src[m.index + tok.length] : "";
        if (!/\d/.test(before) && !/\d/.test(after)) out.add(tok);
      } else if (/^[A-Z]+$/.test(tok)) {
        for (const ch of tok) out.add(ch);
      }
    }
  }

  function collectEinsumLetters(text, out) {
    if (!text) return;
    const re = /[A-Za-z0-9,]+(?:\s*->\s*[A-Za-z0-9,]+)/g;
    let m;
    while ((m = re.exec(String(text)))) {
      for (const ch of m[0]) if (/[A-Za-z]/.test(ch)) out.add(ch);
    }
  }

  function nodesOf(id) {
    if (id === "global") return Object.keys(DATA.globalNodes || {}).map((k) => DATA.globalNodes[k]);
    const v = view(id);
    return (v && v.nodes) || [];
  }

  function usedSymbols(id) {
    const out = new Set();
    for (const n of nodesOf(id)) {
      collectEinsumLetters(n.title, out);
      collectEinsumLetters(n.sub, out);
      if (n.shape) {
        collectShapeLetters(n.shape.sym, out);
        collectShapeLetters(n.shape.real, out);
      }
    }
    return out;
  }

  function expressionsFor(id) {
    const out = [];
    const re = /[A-Za-z0-9,]+(?:\s*->\s*[A-Za-z0-9,]+)/g;
    for (const n of nodesOf(id)) {
      for (const text of [n.title, n.sub]) {
        if (!text) continue;
        let m;
        while ((m = re.exec(String(text)))) {
          if (out.indexOf(m[0]) === -1) out.push(m[0]);
        }
      }
    }
    return out;
  }

  /* Wrap each letter of a shape (`B×T×D`, `BTKGH`) if it has a definition. */
  function shapeHtml(text, id) {
    if (text === undefined || text === null) return "";
    const defs = symbolsFor(id);
    const raw = String(text);
    if (!Object.keys(defs).length) return esc(raw);
    const re = /[A-Za-z][A-Za-z0-9_]*/g;
    let out = "";
    let pos = 0;
    let m;
    while ((m = re.exec(raw))) {
      const tok = m[0];
      let letters = null;
      if (tok.length === 1) {
        const before = m.index ? raw[m.index - 1] : "";
        const after = m.index + tok.length < raw.length ? raw[m.index + tok.length] : "";
        if (!/\d/.test(before) && !/\d/.test(after)) letters = [tok];
      } else if (/^[A-Z]+$/.test(tok)) {
        letters = tok.split("");
      }
      if (!letters) continue;
      out += esc(raw.slice(pos, m.index));
      for (const ch of letters) out += defs[ch] ? symSpan(ch) : esc(ch);
      pos = m.index + tok.length;
    }
    return out + esc(raw.slice(pos));
  }

  /* Wrap every letter inside a `...->...` expression, leaving digits alone. */
  function einsumHtml(text, id) {
    if (text === undefined || text === null) return "";
    const defs = symbolsFor(id);
    const raw = String(text);
    if (!Object.keys(defs).length) return esc(raw);
    const re = /[A-Za-z0-9,]+(?:\s*->\s*[A-Za-z0-9,]+)/g;
    let out = "";
    let pos = 0;
    let m;
    while ((m = re.exec(raw))) {
      out += esc(raw.slice(pos, m.index));
      for (const ch of m[0]) {
        out += /[A-Za-z]/.test(ch) && defs[ch] ? symSpan(ch) : esc(ch);
      }
      pos = m.index + m[0].length;
    }
    return out + esc(raw.slice(pos));
  }

  function richText(text, id) {
    const s = String(text === undefined || text === null ? "" : text);
    return EINSUM_TEST.test(s) ? einsumHtml(s, id) : annotate(s, 1);
  }

  function subHtml(text, id) {
    const s = String(text === undefined || text === null ? "" : text);
    return EINSUM_TEST.test(s) ? einsumHtml(s, id) : esc(s);
  }

  // ---------- parameter ownership ----------
  // A node may carry param_state (train | frozen | n-a) plus param_when, the
  // configuration the claim is about. A bare badge would be a universal claim
  // about weights that only hold for one config, so the qualifier is rendered
  // with the tag instead of living only in a tooltip.
  const PSTATE_LABEL = { train: "train", frozen: "frozen", "n-a": "n-a" };

  function paramTag(n, v) {
    const raw = n.param_state;
    if (!raw) return "";
    const key = String(raw).trim();
    const label = PSTATE_LABEL[key] || key;
    const cls = "ps-" + (key === "train" ? "train" : key === "frozen" ? "frozen" : "na");
    const when = n.param_when ? " · " + n.param_when : "";
    const title = label + (n.param_when ? " — 仅 " + n.param_when : " — 所有配置");
    const matrix = v && v.param_matrix;
    return (
      '<span class="ptag ' +
      cls +
      '"' +
      (matrix ? ' data-drill="' + esc(matrix) + '"' : "") +
      ' title="' +
      esc(title + (matrix ? "（点开参数归属）" : "")) +
      '">' +
      esc(label + when) +
      "</span>"
    );
  }

  const CELL_MARK = {
    train: { cls: "m-train", label: "train" },
    frozen: { cls: "m-frozen", label: "frozen" },
    "n-a": { cls: "m-na", label: "—" },
    na: { cls: "m-na", label: "—" },
  };

  function cellMark(cell) {
    const raw = cell && typeof cell === "object" ? cell.mark : cell;
    return CELL_MARK[raw] || CELL_MARK["n-a"];
  }

  function tableMarkup(n, ctx) {
    const cols = n.cols || [];
    const rows = n.rows || [];
    const head =
      '<tr><th class="rh"></th>' +
      cols
        .map((c) => "<th>" + esc(subst(typeof c === "string" ? c : c.label, ctx)) + "</th>")
        .join("") +
      "</tr>";
    const body = rows
      .map((r) => {
        const cells = (r.cells || [])
          .map((c) => {
            const m = cellMark(c);
            const extra =
              c && typeof c === "object" && c.text ? '<span class="ct">' + esc(c.text) + "</span>" : "";
            return (
              '<td><span class="cell out-' +
              m.cls.slice(2) +
              '"><i class="mk ' +
              m.cls +
              '"></i>' +
              esc(m.label) +
              extra +
              "</span></td>"
            );
          })
          .join("");
        return (
          '<tr><th class="rh"><div class="rl">' +
          esc(subst(r.label || "", ctx)) +
          "</div>" +
          (r.sub ? '<div class="rs">' + esc(subst(r.sub, ctx)) + "</div>" : "") +
          (r.expr ? '<div class="rx" title="' + esc(r.expr) + '">' + esc(r.expr) + "</div>" : "") +
          (r.ref ? '<div class="rf">' + esc(r.ref) + "</div>" : "") +
          "</th>" +
          cells +
          "</tr>"
        );
      })
      .join("");
    const style =
      "left:" + n.x + "px;top:" + n.y + "px;width:" + (n.w || 640) + "px;height:" + (n.h || 240) + "px";
    return (
      '<div class="node k-table' +
      (n.accent ? " ac-" + n.accent : "") +
      '" style="' +
      style +
      '" data-id="' +
      n.id +
      '"' +
      (n.drill ? ' data-drill="' + n.drill + '"' : "") +
      ">" +
      '<div class="tcap">' +
      esc(subst(n.title || "", ctx)) +
      "</div>" +
      (n.sub ? '<div class="tnote">' + esc(subst(n.sub, ctx)) + "</div>" : "") +
      "<table><thead>" +
      head +
      "</thead><tbody>" +
      body +
      "</tbody></table>" +
      (n.key ? '<div class="tkey">' + esc(n.key) + "</div>" : "") +
      "</div>"
    );
  }

  function symbolName(sym) {
    return [sym.name, sym.zh].filter(Boolean).join(" · ");
  }

  function symbolRows(letters, id) {
    const defs = symbolsFor(id);
    return [...letters]
      .filter((ch) => defs[ch])
      .map(
        (ch) =>
          '<div class="symrow"><span class="symbadge">' +
          esc(ch) +
          "</span><span>" +
          (symbolName(defs[ch]) ? "<b>" + esc(symbolName(defs[ch])) + "</b> " : "") +
          esc(defs[ch].detail || "") +
          "</span></div>"
      );
  }

  function symbolNote(n, id) {
    const letters = new Set();
    collectEinsumLetters(n.title, letters);
    collectEinsumLetters(n.sub, letters);
    if (n.shape) {
      collectShapeLetters(n.shape.sym, letters);
      collectShapeLetters(n.shape.real, letters);
    }
    const rows = symbolRows(letters, id);
    if (!rows.length) return "";
    return '<div class="symnote"><b class="symnote-h">符号</b>' + rows.join("") + "</div>";
  }

  function symbolsBlock(id) {
    const rows = symbolRows(usedSymbols(id), id);
    if (!rows.length) return "";
    return '<div class="symnote"><b class="symnote-h">本层符号</b>' + rows.join("") + "</div>";
  }

  /* ------------------------------------------------------------------ */
  /* data helpers                                                        */
  /* ------------------------------------------------------------------ */

  function view(id) {
    return id === "global" ? G : V[id];
  }
  function viewTitle(id) {
    const v = view(id);
    return v ? subst(v.title, ctxFor(v)) : id;
  }
  function pathOf(id) {
    const out = [];
    let cur = id;
    let guard = 0;
    while (cur && guard++ < 20) {
      out.unshift(cur);
      cur = view(cur) && view(cur).parent;
    }
    if (out[0] !== "global") out.unshift("global");
    return out;
  }

  function nodeBox(node) {
    return {
      left: node.x,
      top: node.y,
      right: node.x + (node.w || 200),
      bottom: node.y + (node.h || 86),
      cx: node.x + (node.w || 200) / 2,
      cy: node.y + (node.h || 86) / 2,
    };
  }

  const ROUTE_PAD = 10;

  function segHitsRect(x1, y1, x2, y2, r, pad) {
    if (Math.abs(y1 - y2) < 0.5) {
      if (y1 <= r.top - pad || y1 >= r.bottom + pad) return false;
      return Math.max(x1, x2) > r.left - pad && Math.min(x1, x2) < r.right + pad;
    }
    if (Math.abs(x1 - x2) < 0.5) {
      if (x1 <= r.left - pad || x1 >= r.right + pad) return false;
      return Math.max(y1, y2) > r.top - pad && Math.min(y1, y2) < r.bottom + pad;
    }
    return false;
  }

  function dedupePoints(points) {
    const out = [];
    for (const p of points) {
      const last = out[out.length - 1];
      if (!last || Math.abs(last[0] - p[0]) > 0.5 || Math.abs(last[1] - p[1]) > 0.5) {
        out.push(p);
      }
    }
    return out;
  }

  function routePoints(a, b, obstacles) {
    const pad = ROUTE_PAD;
    const cl = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
    const hGap = b.left >= a.right ? b.left - a.right : a.left >= b.right ? a.left - b.right : -1;
    const vGap = b.top >= a.bottom ? b.top - a.bottom : a.top >= b.bottom ? a.top - b.bottom : -1;
    const horizontal = hGap >= 0 && (vGap < 0 || hGap >= vGap);
    const candidates = [];

    if (horizontal) {
      const rightward = b.cx >= a.cx;
      const x1 = rightward ? a.right : a.left;
      const x2 = rightward ? b.left : b.right;
      const y1 = a.cy;
      const y2 = cl(a.cy, b.top + 12, b.bottom - 12);
      if (Math.abs(y1 - y2) < 1.5) {
        candidates.push([[x1, y1], [x2, y2]]);
      } else {
        const mid = (x1 + x2) / 2;
        candidates.push([[x1, y1], [mid, y1], [mid, y2], [x2, y2]]);
        candidates.push([[x1, y1], [x1 + (rightward ? 18 : -18), y1], [x1 + (rightward ? 18 : -18), y2], [x2, y2]]);
        const laneTop = Math.min(a.top, b.top) - 26;
        const laneBottom = Math.max(a.bottom, b.bottom) + 26;
        candidates.push([[x1, y1], [x1, laneTop], [x2, laneTop], [x2, y2]]);
        candidates.push([[x1, y1], [x1, laneBottom], [x2, laneBottom], [x2, y2]]);
      }
    } else if (vGap >= 0) {
      const downward = b.cy >= a.cy;
      const y1 = downward ? a.bottom : a.top;
      const y2 = downward ? b.top : b.bottom;
      const x1 = cl(a.cx, a.left + 12, a.right - 12);
      const x2 = cl(a.cx, b.left + 12, b.right - 12);
      if (Math.abs(x1 - x2) < 1.5) {
        candidates.push([[x1, y1], [x2, y2]]);
      } else {
        const mid = (y1 + y2) / 2;
        candidates.push([[x1, y1], [x1, mid], [x2, mid], [x2, y2]]);
        candidates.push([[x1, y1], [x1, y1 + (downward ? 18 : -18)], [x2, y1 + (downward ? 18 : -18)], [x2, y2]]);
        const laneLeft = Math.min(a.left, b.left) - 26;
        const laneRight = Math.max(a.right, b.right) + 26;
        candidates.push([[x1, y1], [laneLeft, y1], [laneLeft, y2], [x2, y2]]);
        candidates.push([[x1, y1], [laneRight, y1], [laneRight, y2], [x2, y2]]);
      }
    } else {
      const rightward = b.cx >= a.cx;
      const x1 = rightward ? a.right : a.left;
      const x2 = rightward ? b.left : b.right;
      candidates.push([[x1, a.cy], [x2, b.cy]]);
    }

    let best = null;
    let bestScore = Infinity;
    for (const path of candidates) {
      const clean = dedupePoints(path);
      let hits = 0;
      for (const r of obstacles) {
        for (let i = 0; i < clean.length - 1; i++) {
          if (segHitsRect(clean[i][0], clean[i][1], clean[i + 1][0], clean[i + 1][1], r, pad)) {
            hits++;
            break;
          }
        }
      }
      let length = 0;
      for (let i = 1; i < clean.length; i++) {
        length += Math.abs(clean[i][0] - clean[i - 1][0]) + Math.abs(clean[i][1] - clean[i - 1][1]);
      }
      const score = hits * 100000 + length;
      if (score < bestScore) {
        bestScore = score;
        best = clean;
      }
    }
    return best || [[a.cx, a.cy], [b.cx, b.cy]];
  }

  function anchor(a, b) {
    return routePoints(a, b, []);
  }

  /* ------------------------------------------------------------------ */
  /* rendering                                                           */
  /* ------------------------------------------------------------------ */

  function autofitNodes(v, el) {
    if (v.id === "global") return;
    const doms = el.querySelectorAll(".node");
    for (const dom of doms) {
      const data = (v.nodes || []).find((n) => n.id === dom.dataset.id);
      if (!data) continue;
      if (data._baseH === undefined) data._baseH = data.h;
      const cs = getComputedStyle(dom);
      let needed =
        parseFloat(cs.paddingTop) +
        parseFloat(cs.paddingBottom) +
        parseFloat(cs.borderTopWidth) +
        parseFloat(cs.borderBottomWidth) +
        2;
      for (const child of dom.children) {
        const ccs = getComputedStyle(child);
        if (ccs.position === "absolute") continue;
        needed += child.offsetHeight + parseFloat(ccs.marginTop || 0) + parseFloat(ccs.marginBottom || 0);
      }
      needed = Math.ceil(needed);
      if (needed <= dom.offsetHeight + 1) continue;
      let cap = (v.canvas ? v.canvas.h : 900) - (data.y || 0) - 6;
      for (const other of v.nodes) {
        if (other.id === data.id) continue;
        const ox1 = other.x || 0;
        const ox2 = ox1 + (other.w || 200);
        const nx1 = data.x || 0;
        const nx2 = nx1 + (data.w || 200);
        if (ox2 <= nx1 + 8 || ox1 >= nx2 - 8) continue;
        if (other.y > (data.y || 0) + 2) cap = Math.min(cap, other.y - 6);
      }
      const target = Math.min(needed, cap);
      if (target > dom.offsetHeight) {
        data.h = target;
        dom.style.height = target + "px";
      }
    }
  }

  function render(id, mode) {
    const cur = state.stack[state.stack.length - 1];
    if (mode === "push" && id !== cur) {
      state.stack = state.stack.concat([id]);
    } else if (mode === "path") {
      state.stack = pathOf(id);
    }
    if (mode) history.replaceState(null, "", "#/" + state.stack.join("/"));
    const v = view(id);
    if (!v) return;

    state.selected = null;
    hideInspector(false);
    stage.innerHTML = "";

    const el = document.createElement("div");
    el.className = "view " + (v.style || "paper");
    el.style.width = v.canvas.w + "px";
    el.style.height = v.canvas.h + "px";
    el.dataset.view = id;
    stage.appendChild(el);

    if (id === "global") {
      const tpl = $("#global-figure");
      el.appendChild(tpl.content.cloneNode(true));
      const fig = el.querySelector(".fig");
      if (fig) {
        fig.style.width = v.canvas.w + "px";
        fig.style.height = v.canvas.h + "px";
      }
      annotateFigure(el);
    } else {
      for (const n of v.nodes || []) {
        if (n._baseH !== undefined) n.h = n._baseH;
      }
      el.innerHTML = localMarkup(v);
      autofitNodes(v, el);
    }

    el.appendChild(buildSvg(id, v));
    renderCrumbs();
    renderSidebar();
    renderPlainBar();
    updateSymbolsBtn();
    requestAnimationFrame(fit);
  }

  function localMarkup(v) {
    const ctx = ctxFor(v);
    let html = "";
    for (const n of v.nodes) {
      if ((n.kind || "") === "table") {
        html += tableMarkup(n, ctx);
        continue;
      }
      const cls = ["node", "k-" + (n.kind || "card"), "ac-" + (n.accent || "neu")];
      const style =
        "left:" + n.x + "px;top:" + n.y + "px;width:" + (n.w || 200) + "px;height:" + (n.h || 86) + "px";
      const drill = n.drill ? ' data-drill="' + n.drill + '"' : "";
      const shape = n.shape
        ? '<div class="ns">' +
          shapeHtml(subst(state.symbolic ? n.shape.sym : n.shape.real, ctx), v.id) +
          "</div>"
        : "";
      const params =
        n.params && n.params[state.preset]
          ? '<div class="np">' + fmtParams(n.params[state.preset]) + "</div>"
          : "";
      html +=
        '<div class="' +
        cls.join(" ") +
        '" style="' +
        style +
        '" data-id="' +
        n.id +
        '"' +
        (n.param_state ? ' data-pstate="' + esc(n.param_state) + '"' : "") +
        drill +
        ">" +
        params +
        paramTag(n, v) +
        '<div class="nt">' +
        richText(subst(n.title, ctx), v.id) +
        "</div>" +
        (n.sub ? '<div class="nd">' + subHtml(subst(n.sub, ctx), v.id) + "</div>" : "") +
        shape +
        "</div>";
    }
    return html;
  }

  function buildSvg(id, v) {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("class", "links");
    svg.setAttribute("width", v.canvas.w);
    svg.setAttribute("height", v.canvas.h);
    svg.innerHTML =
      '<defs><marker id="ah-' +
      id +
      '" markerUnits="userSpaceOnUse" markerWidth="9" markerHeight="9" refX="9" refY="4.5" orient="auto">' +
      '<path d="M0,0 L9,4.5 L0,9 z" fill="context-stroke"/></marker></defs>';

    const edges =
      id === "global"
        ? DATA.globalLinks.map((l) => ({
            from: l.from,
            to: l.to,
            c: l.c,
            dash: l.dash,
            note: l.note,
            d: l.d,
          }))
        : v.edges || [];

    edges.forEach((e, i) => {
      const color = e.c || "#93a3b5";
      const dash = e.dash ? ' stroke-dasharray="' + e.dash + '"' : "";
      const sw = id === "global" ? 2 : 1.7;
      const obstacles =
        id === "global"
          ? (() => {
              const root = stage.querySelector(".view");
              if (!root) return [];
              return [...root.querySelectorAll(".n, .enc, .strip, .inset")]
                .filter((node) => node.id !== e.from && node.id !== e.to)
                .map((node) => ({
                  left: node.offsetLeft,
                  top: node.offsetTop,
                  right: node.offsetLeft + node.offsetWidth,
                  bottom: node.offsetTop + node.offsetHeight,
                  cx: node.offsetLeft + node.offsetWidth / 2,
                  cy: node.offsetTop + node.offsetHeight / 2,
                }));
            })()
          : (v.nodes || [])
              .filter((n) => n.id !== e.from && n.id !== e.to)
              .map(nodeBox);
      let el;
      if (e.d && e.d.length) {
        const pts = e.d;
        let d = "M" + pts[0] + "," + pts[1];
        for (let k = 2; k < pts.length; k += 2) d += " L" + pts[k] + "," + pts[k + 1];
        el = document.createElementNS(ns, "path");
        el.setAttribute("d", d);
        el.setAttribute("fill", "none");
      } else if (e.via && e.via.length) {
        const a = boxOf(id, e.from);
        const b = boxOf(id, e.to);
        if (!a || !b) return;
        const first = e.via[0];
        const last = e.via[e.via.length - 1];
        const p0 = bound(a, first[0], first[1]);
        const p1 = bound(b, last[0], last[1]);
        let d = "M" + p0[0] + "," + p0[1];
        for (const pt of e.via) d += " L" + pt[0] + "," + pt[1];
        d += " L" + p1[0] + "," + p1[1];
        el = document.createElementNS(ns, "path");
        el.setAttribute("d", d);
        el.setAttribute("fill", "none");
      } else {
        const a = boxOf(id, e.from);
        const b = boxOf(id, e.to);
        if (!a || !b) return;
        const pts = routePoints(a, b, obstacles);
        let d = "M" + pts[0][0] + "," + pts[0][1];
        for (let k = 1; k < pts.length; k++) d += " L" + pts[k][0] + "," + pts[k][1];
        el = document.createElementNS(ns, "path");
        el.setAttribute("d", d);
        el.setAttribute("fill", "none");
        el.setAttribute("stroke-linejoin", "round");
      }
      el.setAttribute("stroke", color);
      el.setAttribute("stroke-width", sw);
      // white casing underneath so crossings stay readable
      const casing = el.cloneNode(false);
      casing.removeAttribute("marker-end");
      casing.setAttribute("stroke", "#ffffff");
      casing.setAttribute("stroke-width", sw + 4);
      casing.setAttribute("stroke-linecap", "round");
      casing.setAttribute("fill", "none");
      casing.style.pointerEvents = "none";
      casing.removeAttribute("data-edge");
      svg.appendChild(casing);
      if (dash) el.setAttribute("stroke-dasharray", e.dash);
      el.setAttribute("marker-end", "url(#ah-" + id + ")");
      el.dataset.edge = String(i);
      el.style.pointerEvents = "none";
      svg.appendChild(el);

      // 16px invisible hit area: thin lines are hard to click, and the visible
      // stroke stays pointer-events:none so hover highlight is handled here.
      const hit = el.cloneNode(false);
      hit.removeAttribute("marker-end");
      hit.setAttribute("class", "hit");
      hit.setAttribute("stroke", "transparent");
      hit.setAttribute("stroke-width", "16");
      hit.removeAttribute("stroke-dasharray");
      hit.dataset.edge = String(i);
      hit.style.pointerEvents = "stroke";
      svg.appendChild(hit);
    });
    return svg;
  }

  function bound(box, px, py) {
    const dx = px - box.cx;
    const dy = py - box.cy;
    const cl = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
    if (Math.abs(dx) >= Math.abs(dy)) {
      return [dx > 0 ? box.right : box.left, cl(py, box.top + 12, box.bottom - 12)];
    }
    return [cl(px, box.left + 12, box.right - 12), dy > 0 ? box.bottom : box.top];
  }

  function boxOf(viewId, nodeId) {
    if (viewId === "global") {
      const el = stage.querySelector('[id="' + nodeId + '"]');
      if (!el) return null;
      return {
        left: el.offsetLeft,
        top: el.offsetTop,
        right: el.offsetLeft + el.offsetWidth,
        bottom: el.offsetTop + el.offsetHeight,
        cx: el.offsetLeft + el.offsetWidth / 2,
        cy: el.offsetTop + el.offsetHeight / 2,
      };
    }
    const v = V[viewId];
    const n = v && v.nodes.find((x) => x.id === nodeId);
    return n ? nodeBox(n) : null;
  }

  /* ------------------------------------------------------------------ */
  /* chrome                                                              */
  /* ------------------------------------------------------------------ */

  function renderCrumbs() {
    const box = $("#crumbs");
    box.innerHTML = state.stack
      .map((id, i) => {
        const cur = i === state.stack.length - 1;
        const t = i === 0 ? "全局" : viewTitle(id);
        return (
          '<a class="' +
          (cur ? "cur" : "") +
          '" data-goto="' +
          id +
          '">' +
          esc(t) +
          "</a>"
        );
      })
      .join('<i>›</i>');
  }

  let sidebarOpen = {};

  function renderSidebar() {
    const box = $("#sidebar");
    let html = "";
    const core = GLOSSARY.filter((g) => g.core);
    if (core.length) {
      html += '<div class="sbh">核心名词</div><div class="ctgrid">';
      for (const g of core) {
        html +=
          '<div class="ct" data-term="' +
          g.id +
          '" title="' +
          esc(g.zh || g.term).replace(/"/g, "&quot;") +
          '"><b>?</b>' +
          esc(g.term) +
          "</div>";
      }
      html += "</div>";
    }
    html += '<div class="sbh">结构树</div><ul>';
    html += sbItem("global", "全局视图", 1, ["global"]);
    const walk = (id, depth, path) => {
      const v = view(id);
      if (!v) return "";
      let out = sbItem(id, v.title, depth, path);
      if (sidebarOpen[id] !== false) {
        for (const child of v.children || []) out += walk(child, depth + 1, path.concat([child]));
      }
      return out;
    };
    for (const id of DATA.tree) html += walk(id, 2, ["global", id]);
    html += "</ul>";
    box.innerHTML = html;
  }

  function sbItem(id, label, depth, path) {
    const active = state.stack[state.stack.length - 1] === id ? " active" : "";
    return (
      '<li><div class="sb lv' +
      depth +
      active +
      '" data-goto="' +
      id +
      '" data-path="' +
      (path || [id]).join("/") +
      '"><span class="dot" style="background:' +
      accentOf(id) +
      '"></span><span class="t">' +
      esc(subst(label, view(id) ? ctxFor(view(id)) : {})) +
      "</span></div></li>"
    );
  }

  function accentOf(id) {
    return (DATA.viewAccents && DATA.viewAccents[id]) || "#8798ab";
  }

  /* ------------------------------------------------------------------ */
  /* inspector                                                           */
  /* ------------------------------------------------------------------ */

  function showInspector(html) {
    const wasHidden = inspector.classList.contains("hidden");
    inspectorBody.innerHTML = html;
    inspector.classList.remove("hidden");
    document.body.classList.add("insp");
    if (wasHidden) requestAnimationFrame(fit);
  }
  function hideInspector(adjust) {
    if (inspector.classList.contains("hidden")) return;
    inspector.classList.add("hidden");
    inspectorBody.innerHTML = "";
    document.body.classList.remove("insp");
    if (adjust) requestAnimationFrame(fit);
  }

  function showNode(viewId, nodeId) {
    const v = view(viewId);
    if (!v) return;
    const n = (v.nodes || []).find((x) => x.id === nodeId);
    if (!n) return;
    const ctx = ctxFor(v);
    const shape = n.shape
      ? '<div class="row"><b>shape</b><br><span class="shape">' +
        shapeHtml(subst(state.symbolic ? n.shape.sym : n.shape.real, ctx), viewId) +
        "</span> " +
        '<span class="kbd">' +
        shapeHtml(subst(state.symbolic ? n.shape.real : n.shape.sym, ctx), viewId) +
        "</span></div>"
      : "";
    const params =
      n.params && n.params[state.preset]
        ? '<div class="row"><b>参数量</b> <span class="kbd">' + fmtParams(n.params[state.preset]) + "</span></div>"
        : "";
    const drill = n.drill
      ? '<div class="row"><b>下钻</b> <a href="#" data-goto="' + n.drill + '">' + esc(subst(viewTitle(n.drill), ctx)) + " →</a></div>"
      : "";
    const code = n.code ? codeHtml(n.code) : "";
    showInspector(
      "<h2>" +
        subHtml(subst(n.title, ctx), viewId) +
        "</h2>" +
        (n.sub ? '<div class="sub">' + subHtml(subst(n.sub, ctx), viewId) + "</div>" : "") +
        termNote(subst(n.title, ctx), n.term) +
        symbolNote(n, viewId) +
        shape +
        params +
        (n.derive ? '<div class="row"><b>推导</b> ' + esc(n.derive) + "</div>" : "") +
        drill +
        (n.note ? '<div class="note">' + esc(n.note) + "</div>" : "") +
        (n.code ? code : "")
    );
  }

  function showEdge(viewId, index) {
    const v = view(viewId);
    const edges =
      viewId === "global"
        ? DATA.globalLinks
        : v.edges || [];
    const e = edges[index];
    if (!e) return;
    const from = viewId === "global" ? DATA.globalNodes[e.from] : null;
    const to = viewId === "global" ? DATA.globalNodes[e.to] : null;
    const fromLabel = from ? from.title : e.from ? labelOf(viewId, e.from) : "显式路径";
    const toLabel = to ? to.title : e.to ? labelOf(viewId, e.to) : "";
    showInspector(
      "<h2>连线</h2>" +
        '<div class="sub">' +
        esc(fromLabel || "") +
        (toLabel ? " → " + esc(toLabel) : "") +
        "</div>" +
        '<div class="note">' +
        esc(e.note || "数据流：" + (fromLabel || "") + " → " + (toLabel || "")) +
        "</div>"
    );
  }

  function labelOf(viewId, nodeId) {
    const v = view(viewId);
    const n = (v.nodes || []).find((x) => x.id === nodeId);
    return n ? subst(n.title, ctxFor(v)) : nodeId;
  }

  function showGlobalNode(id) {
    const meta = DATA.globalNodes[id];
    if (!meta) {
      showInspector("<h2>" + esc(id) + '</h2><div class="empty">这个元素在全局图里没有单独标注。</div>');
      return;
    }
    showInspector(
      "<h2>" +
        subHtml(meta.title, "global") +
        "</h2>" +
        (meta.sub ? '<div class="sub">' + subHtml(meta.sub, "global") + "</div>" : "") +
        termNote(meta.title, meta.term) +
        symbolNote(meta, "global") +
        (meta.shape
          ? '<div class="row"><b>shape</b><br><span class="shape">' + shapeHtml(meta.shape, "global") + "</span></div>"
          : "") +
        (meta.note ? '<div class="note">' + esc(meta.note) + "</div>" : "")
    );
  }

  function showViewInfo(id) {
    const v = view(id);
    if (!v) return;
    showInspector(
      "<h2>" + esc(v.title) + "</h2>" +
        (v.subtitle ? '<div class="sub">' + esc(v.subtitle) + "</div>" : "") +
        (v.plain
          ? '<div class="plainnote"><b>这层在干什么：</b>' + annotate(v.plain, 2) + "</div>"
          : "") +
        symbolsBlock(id) +
        (v.summary ? '<div class="note">' + esc(v.summary) + "</div>" : "") +
        (v.source
          ? '<div class="src">' + esc(v.source.file) + " : " + v.source.line + "</div>"
          : "") +
        (v.code ? codeHtml(v.code) : "")
    );
  }

  /* ------------------------------------------------------------------ */
  /* beginner layer: UI                                                  */
  /* ------------------------------------------------------------------ */

  const plainbar = $("#plainbar");
  const pbText = $("#pbText");
  const pbChips = $("#pbChips");
  const tip = $("#tip");
  const glossary = $("#glossary");
  const gbody = $("#gbody");
  const gsearch = $("#gsearch");
  const gcount = $("#gcount");
  const symbolsOverlay = $("#symbols");
  const symSub = $("#symSub");
  const symBody = $("#symBody");

  function termNote(title, explicitId) {
    const id = explicitId && TERM_BY_ID[explicitId] ? explicitId : termForText(title);
    if (!id) return "";
    const g = TERM_BY_ID[id];
    if (!g || !g.plain) return "";
    return (
      '<div class="plainnote"><b>人话：</b>' +
      esc(g.plain) +
      ' <a href="#" data-term="' +
      id +
      '">完整解释 →</a></div>'
    );
  }

  function renderPlainBar() {
    if (!plainbar) return;
    const cur = state.stack[state.stack.length - 1];
    const v = view(cur);
    const text = (v && v.plain) || "";
    const ids = (v && v.plain_terms) || [];
    if (!text && !ids.length) {
      plainbar.classList.add("hidden");
      document.body.classList.remove("plainbar");
      return;
    }
    plainbar.classList.remove("hidden");
    document.body.classList.add("plainbar");
    if (pbText) pbText.innerHTML = annotate(text, 3);
    if (pbChips) {
      pbChips.innerHTML = ids
        .map((id) => {
          const g = TERM_BY_ID[id];
          if (!g) return "";
          return '<span class="termchip" data-term="' + id + '">' + esc(g.term) + " <b>?</b></span>";
        })
        .join("");
    }
  }

  /* -------- hover tooltip -------- */
  let tipTimer = null;
  function showTip(host) {
    if (!tip) return;
    if (host.dataset.sym) {
      const id = state.stack[state.stack.length - 1];
      const s = symbolsFor(id)[host.dataset.sym];
      if (!s) return;
      tip.innerHTML =
        "<b>" + esc(host.dataset.sym) +
        (s.name ? " · " + esc(s.name) : "") +
        (s.zh ? " · " + esc(s.zh) : "") + "</b>" +
        esc(s.detail || "") +
        '<span class="tip-foot">点击查看符号表</span>';
    } else {
      const g = TERM_BY_ID[host.dataset.term];
      if (!g) return;
      tip.innerHTML =
        "<b>" + esc(g.term) + (g.zh ? " · " + esc(g.zh) : "") + "</b>" +
        esc(g.plain) +
        (g.analogy ? '<span class="tip-ana">打个比方：' + esc(g.analogy) + "</span>" : "") +
        '<span class="tip-foot">点击查看完整解释</span>';
    }
    tip.classList.add("on");
    const r = host.getBoundingClientRect();
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;
    let x = r.left + r.width / 2 - w / 2;
    let y = r.bottom + 8;
    x = Math.max(10, Math.min(window.innerWidth - w - 10, x));
    if (y + h > window.innerHeight - 10) y = r.top - h - 8;
    tip.style.left = x + "px";
    tip.style.top = Math.max(8, y) + "px";
  }
  function hideTip() {
    if (tipTimer) {
      clearTimeout(tipTimer);
      tipTimer = null;
    }
    if (tip) tip.classList.remove("on");
  }

  document.addEventListener("mouseover", (ev) => {
    const host = ev.target.closest(".term,.termchip,.ct,.sym");
    if (!host || (!HAS_GLOSSARY && !host.dataset.sym)) return;
    if (tipTimer) clearTimeout(tipTimer);
    tipTimer = setTimeout(() => showTip(host), 110);
  });
  document.addEventListener("mouseout", (ev) => {
    const host = ev.target.closest(".term,.termchip,.ct,.sym");
    if (!host) return;
    if (ev.relatedTarget && host.contains(ev.relatedTarget)) return;
    hideTip();
  });
  window.addEventListener("scroll", hideTip, true);

  /* -------- glossary modal -------- */
  function cardHtml(g) {
    const where = (g.views || [])
      .map(
        (id) =>
          '<a href="#/' + id + '" data-goto="' + id + '">' + esc(viewShort(id)) + "</a>"
      )
      .join("");
    return (
      '<article class="gcard" id="g-' + g.id + '" data-id="' + g.id + '">' +
        "<h4>" + (g.core ? '<span class="corestar">★</span>' : "") + esc(g.term) +
          (g.zh ? '<span class="zh">' + esc(g.zh) + "</span>" : "") + "</h4>" +
        '<div class="plain">' + esc(g.plain) + "</div>" +
        (g.analogy ? '<div class="ana"><b>打个比方：</b>' + esc(g.analogy) + "</div>" : "") +
        (g.detail
          ? '<details class="more"><summary>再深入一点（技术细节）</summary><div>' + esc(g.detail) + "</div></details>"
          : "") +
        (where ? '<div class="where"><span>在图中：</span>' + where + "</div>" : "") +
      "</article>"
    );
  }

  function renderGlossary(q) {
    if (!gbody) return;
    const needle = (q || "").trim().toLowerCase();
    let shown = 0;
    let html = "";
    for (const cat of CATS) {
      const items = GLOSSARY.filter((g) => {
        if ((g.category || "其他") !== cat) return false;
        if (!needle) return true;
        return (
          g.term.toLowerCase().includes(needle) ||
          (g.zh || "").toLowerCase().includes(needle) ||
          (g.plain || "").toLowerCase().includes(needle) ||
          (g.detail || "").toLowerCase().includes(needle) ||
          (g.analogy || "").toLowerCase().includes(needle) ||
          (g.aliases || []).some((a) => a.toLowerCase().includes(needle))
        );
      });
      if (!items.length) continue;
      shown += items.length;
      html +=
        '<div class="gsec">' + esc(cat) + "</div>" +
        '<div class="ggrid">' + items.map(cardHtml).join("") + "</div>";
    }
    gbody.innerHTML = shown ? html : '<div class="gempty">没有找到匹配的词，换个更短的关键词试试。</div>';
    if (needle) {
      gbody.querySelectorAll(".gcard").forEach((card) => {
        const g = TERM_BY_ID[card.dataset.id];
        if (!g) return;
        const direct = (g.term + " " + (g.zh || "") + " " + (g.plain || "") + " " + (g.analogy || "")).toLowerCase();
        if (!direct.includes(needle) && (g.detail || "").toLowerCase().includes(needle)) {
          const d = card.querySelector("details");
          if (d) d.open = true;
        }
      });
    }
    if (gcount) gcount.textContent = shown + " 个词条";
  }

  function focusTerm(id) {
    const card = document.getElementById("g-" + id);
    if (!card) return;
    card.scrollIntoView({ block: "center", behavior: "smooth" });
    card.classList.add("hit");
    setTimeout(() => card.classList.remove("hit"), 1800);
  }

  function openGlossary(id) {
    if (!glossary) return;
    hideTip();
    glossary.classList.remove("hidden");
    if (gsearch) gsearch.value = "";
    renderGlossary("");
    if (id) {
      requestAnimationFrame(() => requestAnimationFrame(() => focusTerm(id)));
    } else if (gsearch) {
      gsearch.focus();
    }
  }
  function closeGlossary() {
    if (glossary) glossary.classList.add("hidden");
  }

  /* -------- symbols modal -------- */
  function focusSymbol(letter) {
    const row = document.getElementById("sym-" + letter);
    if (!row) return;
    row.scrollIntoView({ block: "center", behavior: "smooth" });
    row.classList.add("hit");
    setTimeout(() => row.classList.remove("hit"), 1800);
  }

  function renderSymbols(focus) {
    if (!symBody) return;
    const id = state.stack[state.stack.length - 1];
    const defs = symbolsFor(id);
    const used = usedSymbols(id);
    const keys = Object.keys(defs).sort((a, b) => {
      const ua = used.has(a) ? 0 : 1;
      const ub = used.has(b) ? 0 : 1;
      return ua - ub || a.localeCompare(b);
    });
    if (!keys.length) {
      symBody.innerHTML = '<tr><td colspan="3" class="gempty">本层没有定义符号。</td></tr>';
    } else {
      symBody.innerHTML = keys
        .map((ch) => {
          const s = defs[ch];
          return (
            '<tr id="sym-' + ch + '" class="' + (used.has(ch) ? "used" : "") + '">' +
              '<td><span class="symbadge">' + esc(ch) + "</span>" +
                (used.has(ch) ? '<span class="symused">本层</span>' : "") + "</td>" +
              "<td>" + (s.name ? "<b>" + esc(s.name) + "</b>" : "") +
                (s.zh ? (s.name ? "<br>" : "") + '<span class="symzh">' + esc(s.zh) + "</span>" : "") +
              "</td>" +
              "<td>" + esc(s.detail || "") + "</td>" +
            "</tr>"
          );
        })
        .join("");
    }
    if (symSub) {
      const exprs = expressionsFor(id);
      symSub.innerHTML =
        "当前视图：" + esc(viewShort(id)) +
        "。带虚线下划线的字母在图上悬停也会出解释；点字母可直接定位到本表。" +
        (exprs.length
          ? "<br>本层表达式：" + exprs.map((e) => "<code>" + esc(e) + "</code>").join("　")
          : "");
    }
    if (focus) {
      requestAnimationFrame(() => requestAnimationFrame(() => focusSymbol(focus)));
    }
  }

  function updateSymbolsBtn() {
    const btn = $("#symbolsBtn");
    if (!btn) return;
    const id = state.stack[state.stack.length - 1];
    btn.style.display = usedSymbols(id).size ? "" : "none";
  }

  function openSymbols(letter) {
    if (!symbolsOverlay) return;
    const id = state.stack[state.stack.length - 1];
    if (!usedSymbols(id).size) return;
    hideTip();
    symbolsOverlay.classList.remove("hidden");
    renderSymbols(letter);
  }
  function closeSymbols() {
    if (symbolsOverlay) symbolsOverlay.classList.add("hidden");
  }

  document.querySelectorAll("[data-close-symbols]").forEach((el) =>
    el.addEventListener("click", closeSymbols)
  );

  document.querySelectorAll("[data-close-glossary]").forEach((el) =>
    el.addEventListener("click", closeGlossary)
  );
  if (gsearch) gsearch.addEventListener("input", () => renderGlossary(gsearch.value));
  if (gbody) {
    gbody.addEventListener("click", (ev) => {
      if (ev.target.closest("[data-goto]")) closeGlossary();
    });
  }

  /* -------- term / symbol links everywhere -------- */
  document.addEventListener(
    "click",
    (ev) => {
      const host = ev.target.closest(".sym");
      if (!host) return;
      ev.preventDefault();
      ev.stopPropagation();
      hideTip();
      openSymbols(host.dataset.sym);
    },
    true
  );

  document.addEventListener(
    "click",
    (ev) => {
      const host = ev.target.closest(".term,.termchip,.ct,[data-term]");
      if (!host || !HAS_GLOSSARY) return;
      if (host.closest("#glossary")) return;
      ev.preventDefault();
      ev.stopPropagation();
      hideTip();
      openGlossary(host.dataset.term);
    },
    true
  );

  function annotateFigure(el) {
    el.querySelectorAll(".n .nt, .enc .et, .strip .st, .n .nd, .enc .ed").forEach((node) => {
      const text = node.textContent;
      if (EINSUM_TEST.test(text)) node.innerHTML = einsumHtml(text, "global");
      else if (TERM_RE && termForText(text)) node.innerHTML = annotate(text, 1);
    });
    el.querySelectorAll(".ns").forEach((node) => {
      node.innerHTML = shapeHtml(node.textContent, "global");
    });
  }

  /* ------------------------------------------------------------------ */
  /* zoom / pan                                                          */
  /* ------------------------------------------------------------------ */

  function applyTransform() {
    stage.style.transform =
      "translate(" + state.pan.x + "px," + state.pan.y + "px) scale(" + state.zoom + ")";
  }

  function fit() {
    const v = view(state.stack[state.stack.length - 1]);
    if (!v) return;
    const w = wrap.clientWidth - 56;
    const h = wrap.clientHeight - 56;
    state.zoom = Math.min(1, Math.min(w / v.canvas.w, h / v.canvas.h));
    state.pan = {
      x: Math.max(28, (wrap.clientWidth - v.canvas.w * state.zoom) / 2),
      y: Math.max(28, (wrap.clientHeight - v.canvas.h * state.zoom) / 2),
    };
    applyTransform();
  }

  /* ------------------------------------------------------------------ */
  /* events                                                              */
  /* ------------------------------------------------------------------ */

  stage.addEventListener("click", (ev) => {
    const drill = ev.target.closest("[data-drill]");
    if (drill) {
      ev.preventDefault();
      render(drill.dataset.drill, "push");
      return;
    }
    const edge = ev.target.closest("[data-edge]");
    if (edge) {
      ev.preventDefault();
      showEdge(state.stack[state.stack.length - 1], Number(edge.dataset.edge));
      return;
    }
    const node = ev.target.closest(".node");
    if (node) {
      stage.querySelectorAll(".node.sel").forEach((x) => x.classList.remove("sel"));
      node.classList.add("sel");
      showNode(state.stack[state.stack.length - 1], node.dataset.id);
      return;
    }
    const gnode = ev.target.closest("[id]");
    if (gnode && gnode.id && stage.contains(gnode)) {
      showGlobalNode(gnode.id);
    }
  });

  document.addEventListener("click", (ev) => {
    const go = ev.target.closest("[data-goto]");
    if (!go) return;
    ev.preventDefault();
    if (go.dataset.path) {
      state.stack = go.dataset.path.split("/");
      render(state.stack[state.stack.length - 1], null);
      history.replaceState(null, "", "#/" + state.stack.join("/"));
    } else {
      render(go.dataset.goto, "path");
    }
  });

  document.addEventListener("keydown", (ev) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName);
    if (ev.key === "Escape") {
      if (symbolsOverlay && !symbolsOverlay.classList.contains("hidden")) closeSymbols();
      else if (glossary && !glossary.classList.contains("hidden")) closeGlossary();
      else if (!inspector.classList.contains("hidden")) hideInspector(true);
      else back();
    } else if (ev.key === "ArrowLeft" && !typing && !ev.metaKey && !ev.ctrlKey) {
      back();
    } else if (
      (ev.key === "g" || ev.key === "G") &&
      !typing &&
      !ev.metaKey &&
      !ev.ctrlKey &&
      !ev.altKey
    ) {
      if (HAS_GLOSSARY) openGlossary();
    } else if (
      (ev.key === "s" || ev.key === "S") &&
      !typing &&
      !ev.metaKey &&
      !ev.ctrlKey &&
      !ev.altKey
    ) {
      openSymbols();
    }
  });

  function back() {
    if (state.stack.length > 1) {
      state.stack.pop();
      render(state.stack[state.stack.length - 1], null);
      history.replaceState(null, "", "#/" + state.stack.join("/"));
    }
  }

  wrap.addEventListener(
    "wheel",
    (ev) => {
      ev.preventDefault();
      const dir = ev.deltaY > 0 ? -1 : 1;
      const next = Math.min(2, Math.max(0.2, state.zoom * (1 + dir * 0.08)));
      const rect = wrap.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      const k = next / state.zoom;
      state.pan = {
        x: mx - (mx - state.pan.x) * k,
        y: my - (my - state.pan.y) * k,
      };
      state.zoom = next;
      applyTransform();
    },
    { passive: false }
  );

  let drag = null;
  wrap.addEventListener("mousedown", (ev) => {
    if (ev.target.closest(".node") || ev.target.closest("[data-drill]")) return;
    if (ev.button !== 0) return;
    drag = { x: ev.clientX, y: ev.clientY, px: state.pan.x, py: state.pan.y };
    wrap.style.cursor = "grabbing";
  });
  window.addEventListener("mousemove", (ev) => {
    if (!drag) return;
    state.pan = { x: drag.px + (ev.clientX - drag.x), y: drag.py + (ev.clientY - drag.y) };
    applyTransform();
  });
  window.addEventListener("mouseup", () => {
    drag = null;
    wrap.style.cursor = "";
  });

  $("#closeInspector").addEventListener("click", () => hideInspector(true));
  $("#info").addEventListener("click", () =>
    showViewInfo(state.stack[state.stack.length - 1])
  );
  const glossaryBtn = $("#glossaryBtn");
  if (glossaryBtn) {
    if (!HAS_GLOSSARY) glossaryBtn.style.display = "none";
    else glossaryBtn.addEventListener("click", () => openGlossary());
  }
  const symbolsBtn = $("#symbolsBtn");
  if (symbolsBtn) symbolsBtn.addEventListener("click", () => openSymbols());
  $("#fit").addEventListener("click", fit);
  $("#one").addEventListener("click", () => {
    state.zoom = 1;
    state.pan = { x: 28, y: 28 };
    applyTransform();
  });
  $("#zoomIn").addEventListener("click", () => {
    state.zoom = Math.min(2, state.zoom * 1.15);
    applyTransform();
  });
  $("#zoomOut").addEventListener("click", () => {
    state.zoom = Math.max(0.2, state.zoom / 1.15);
    applyTransform();
  });

  const symBtn = $("#sym");
  symBtn.addEventListener("click", () => {
    state.symbolic = !state.symbolic;
    symBtn.classList.toggle("on", state.symbolic);
    const cur = state.stack[state.stack.length - 1];
    const wasOpen = !inspector.classList.contains("hidden");
    render(cur, null);
    if (wasOpen && cur !== "global") showViewInfo(cur);
  });

  const sel = $("#preset");
  if (Object.keys(P).length) {
    for (const [key, p] of Object.entries(P)) {
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = p.label || key;
      sel.appendChild(opt);
    }
    sel.value = state.preset;
    sel.addEventListener("change", () => {
      state.preset = sel.value;
      const cur = state.stack[state.stack.length - 1];
      const wasOpen = !inspector.classList.contains("hidden");
      render(cur, null);
      if (wasOpen && cur !== "global") showViewInfo(cur);
    });
  } else {
    const label = sel.closest(".tool");
    if (label) label.style.display = "none";
  }

  if (DATA.meta && DATA.meta.stats) {
    const box = $("#stats");
    if (box) box.textContent = DATA.meta.stats;
  }

  const hasShapes = Object.values(V).some((v) =>
    (v.nodes || []).some((n) => n.shape)
  );
  if (!hasShapes) symBtn.style.display = "none";

  /* ------------------------------------------------------------------ */
  /* boot                                                                */
  /* ------------------------------------------------------------------ */

  function boot() {
    const hash = location.hash.replace(/^#\/?/, "");
    if (hash) {
      const parts = hash.split("/").filter(Boolean);
      const valid = parts.filter((id) => view(id));
      if (valid.length) state.stack = valid;
    }
    render(state.stack[state.stack.length - 1], null);
  }

  window.addEventListener("hashchange", () => {
    const parts = location.hash.replace(/^#\/?/, "").split("/").filter((id) => view(id));
    if (!parts.length) return;
    if (parts.join("/") === state.stack.join("/")) return;
    state.stack = parts;
    render(parts[parts.length - 1], null);
  });

  boot();
})();
