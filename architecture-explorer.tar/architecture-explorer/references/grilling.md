# Grilling the exploration plan

Not every repository is a model with five encoders and a DiT. A monorepo, a
plugin host, a notebook dump, a generated SDK, and a data pipeline all need a
different shape of explorer. The fixed pipeline in `SKILL.md` is the default,
not a law.

Before you commit to a branch taxonomy, **grill the plan**. The protocol is
adapted from the `grilling` skill (and `grill-me`): interview until the
exploration design is shared understanding, not until you have enough words to
start drawing.

## The protocol

1. Build a **design tree**: the root is "what kind of walkthrough does this repo
   need?", and each decision branches into the decisions that depend on it.
2. The **frontier** is every decision whose prerequisites are settled — the
   questions you can ask now without guessing at answers you have not heard.
3. Ask **one frontier question per round** (this user's standing preference),
   number it, and give a recommended answer. If the user says "ask them all",
   ask the whole frontier in one round.
4. Wait for the answer. It reshapes the tree: settled decisions unblock the next
   frontier. Recompute, ask the next question.
5. **Facts are your job, not the user's.** If a question needs a fact from the
   repo, dispatch a sub-agent or run `recon.py`; never ask the user what you can
   look up. Decisions are the user's; put each to them and wait.
6. Stop when the frontier is empty. Write the answers to
   `spec/decisions.md`, then confirm: "these are the assumptions; anything to
   change?" Do not build before the user confirms.

Format:

```
❓ Q1 — <short title>: <question, including the realistic choices>

➡️ 推荐：<your answer and the one-line reason>
```

Word it so "yes" accepts the recommendation. Do not hide a decision inside a
factual statement.

## The design tree

### 1. Scope and runtime path

The same repo often contains training, inference, serving, evaluation, and a
CLI. They are different walkthroughs.

- Which path is the subject? (default: the path the README uses in its first
  runnable example)
- Is the repo a monorepo? One package, one deployable, or a meta-map?
- Is the user asking "how does it work?" (mechanism) or "where do I change X?"
  (navigation)? The second needs fewer, deeper branches.

### 2. Unit of analysis (the branch cut)

What is one branch?

- **data family** — text / image / video / action / state (ML encoders);
- **pipeline stage** — ingest / transform / index / serve;
- **deployable** — service / worker / CLI / scheduler (monorepo);
- **extension point** — hook / plugin / middleware (frameworks);
- **IR or pass** — parse / lower / optimize / emit (compilers).

The wrong cut is usually a directory or a class. Ask which cut makes the data
flow legible. Default: the cut that makes each branch independently explainable.

### 3. Terminal floor

What is a primitive *in this domain*?

- ML: a framework op (`torch.bmm`, `F.relu`) or a kernel launch;
- service: the ORM query, HTTP client, template render, cache call;
- CLI: the stdlib file/JSON boundary;
- compiler: the IR builder call that performs the rewrite;
- frontend: the DOM write / API call / state update.

If the repo delegates to a C extension, a generated client, or a remote service,
the terminal is that boundary — cite the wrapper and the boundary, and mark the
generated side with `terminal_reason`.

### 4. Depth allocation

You cannot read everything. Decide explicitly:

- Which paths get full depth (to the primitive) and which stop at a module map?
- Is the hot path (inference/serve) more important than the long tail?
- How many views is "enough" for this repo? (small: 8–15, medium: 25–40,
  large: 40–60; above that, split into multiple explorers)

**If the path is training or finetuning, settle parameter ownership here.**

- Which configuration is the subject — full finetune, LoRA, or "show the
  difference"? A freeze filter is per-config, so "which weights train" has no
  answer until this is decided.
- What is a row in the matrix: one per config name, or one per **distinct freeze
  expression**? (default: distinct expression — twenty configs that all leave
  the filter at `nnx.Nothing` are one behaviour, and twenty rows hide that)
- What is a column: module, module × adapter, or parameter-path pattern? (default:
  module, split whenever a group is partly frozen)
- Is `n-a` allowed, or should a non-existent module drop its column?
- Evidence: can you enumerate the parameter tree at runtime (`nnx.state(…,
  filter)`), or must the matrix be derived by reading the filter? Say which —
  counts are only honest when the tree was actually walked.

### 5. Evidence standard

- Code at `file:line` is primary.
- Are configs, schemas, generated code, or tests acceptable as evidence for a
  claim? If yes, say which.
- Is the repo's documentation trusted, or only the executable path?
- What do you do when the behavior is assembled at runtime (dependency
  injection, plugin registry, dynamic dispatch)? Trace one concrete registration
  and name it as the representative path.

### 6. Audience and language

- Paper-style mechanism figure, or engineering navigation map?
- Chinese labels, English labels, or both?
- Is the reader expected to know the domain? This decides how much a `note`
  node explains.

### 7. Non-goals

Name what the explorer will **not** cover: tests, vendored dependencies,
generated clients, infrastructure, training data loaders, deprecated paths.
Writing this down prevents the analysis from silently expanding.

### 8. Output contract

- Single `explorer.html` + `architecture.html` in `docs/architecture/`?
- Is the spec kept in the repo for rebuilds?
- Does the user want screenshots, a PDF, or just the HTML?

## When to grill, and how hard

**Short grill (one round, one question):** the entrypoint is unambiguous, there
is a single runtime path, and the default taxonomy fits. Ask only the one
decision that could change the branch cut, e.g. "inference or training?".

**Full grill (several rounds):** any of these is true:

- monorepo or multiple deployables;
- several plausible entrypoints;
- a domain the default taxonomy does not cover (plugin host, compiler,
  data pipeline, notebook research, generated SDK);
- the repo has several finetuning configurations and "which weights train" is
  the question the reader actually has;
- the user has a specific question ("where does latency come from?") that
  changes what deserves depth;
- the estimate exceeds ~40 views, so scope must be cut.

**Skip the grill only when** the user explicitly says "use the defaults" or
"just do it". Even then, write the assumptions to `decisions.md` so they are
visible and correctable.

## Question bank

Use these as prompts, not a script. Ask only the frontier.

- "This repo has a training entry and a serving entry. Which one is the
  subject?" (default: serving if the user is deploying, training if the user is
  reproducing)
- "Is one package the subject, or the whole monorepo?" (default: the package
  with the README's primary command)
- "What is a branch here — data family, pipeline stage, or deployable?"
- "Where should a branch stop: framework call, DB query, HTTP boundary, IR
  node?" (default: the first boundary outside the repo)
- "Which path gets full operator-level depth, and which can stop at a module
  map?"
- "Which weights does the optimizer update — and for which config? Show me the
  freeze filter line."
- "Is the row axis config names or distinct freeze expressions?"
- "Should generated/vendored code be drawn, cited, or excluded?"
- "Chinese or English labels? Paper-style or engineering map?"
- "What is explicitly out of scope?"

## Repos that resist the default

- **Monorepo:** either one explorer per deployable with a small meta-map, or a
  meta-explorer whose branches are deployables and whose leaves are their public
  contracts. Do not mix both in one canvas.
- **Framework / plugin host:** global = request or lifecycle; branches =
  extension points; terminal = the hook invocation plus one concrete plugin.
- **Data pipeline / DAG:** global = the DAG; branches = operator families;
  terminal = the engine primitive (`spark.sql`, `pandas.merge`, the UDF call).
- **Notebook / research repo:** global = experiment pipeline; branches = data,
  model, loss, eval; terminal = tensor ops. Cells are not modules; cite the
  function the notebook calls.
- **Thin SDK / API wrapper:** global = public API surface; branches = endpoints
  or adapters; terminal = the upstream HTTP/SDK call.
- **Generated code:** do not reverse-engineer the generated file. Cite the
  generator/schema, mark the leaf `terminal_reason: generated`, and point at the
  template.
- **Multi-language:** cut by runtime boundary, not by language. A Python
  trainer with a C++ kernel is one branch at the kernel boundary.
- **Config-driven system:** the config is first-class evidence. Put the
  dimensions in `presets.yaml`; a branch that only exists for one config is a
  preset, not a branch.

## Exit criteria

The frontier is empty when every one of these has an answer, not an assumption:

- [ ] runtime path and scope;
- [ ] branch cut and branch list;
- [ ] terminal floor;
- [ ] depth allocation and view budget;
- [ ] parameter ownership: matrix rows, columns, and the line that decides each
      row (skip only if the explorer has no training path);
- [ ] evidence standard for configs/generated code;
- [ ] audience, language, visual style;
- [ ] non-goals;
- [ ] output location and rebuild contract.

Write them to `spec/decisions.md`, show the file, and ask for confirmation.
Only then start the blueprint. `check.py` warns if `decisions.md` is missing or
still contains `TODO`.
