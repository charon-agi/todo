# Visual language

Two styles, two jobs. The style change is a signal to the reader that they have
descended a level — do not use the graph style for a module overview, and do not
use the paper style for a tensor operation.

## Palette

The default palette encodes **data family**, not decoration:

| name | hex | family |
| --- | --- | --- |
| `text` | `#6d5fc7` | text / language |
| `video` | `#3f7fc4` | pixels / video / image |
| `action` | `#cf7f34` | actions / control |
| `state` | `#2f9e6f` | state / proprioception |
| `neu` | `#8798ab` | neutral / structural |

If the repo has different families, rename them in `meta.accents` but keep the
same discipline: one hue per family, used consistently across every view.

## Canvas and grid

- Global: `1800×900` minimum; `2640×880` for a two-panel paper figure.
- Local module/block: `1500–1600 × 700–900`.
- Operator page: `1200–1400 × 620–760`.
- Node: 180–260 wide, 80–100 tall; use ≥ 86 when a shape line is present.
- Horizontal gap: 40–60. Vertical gap: 20–40.
- A shape is a monospace text line under the subtitle, not a pill. Long shapes
  wrap; the renderer grows the node when it can, but do not rely on that inside
  a tight vertical stack.
- Margins: 40–60. Leave room for a note strip at the bottom if needed.
- One idea per node. If a node needs three lines of explanation, it is a view.

Layout flows left-to-right. Inputs on the left, outputs on the right. Secondary
inputs (timesteps, masks, states) enter from below or above with routed edges.
Loops go below the main row and return to the left.

## Paper style (module / block)

Use for: subsystem overviews, block diagrams, pipeline stages, closed loops.

Node kinds:

- `card` — ordinary box.
- `enc` — slanted block for an encoder/stage.
- `strip` — one lane of a sequence/pipeline.
- `note` — dashed box for a caveat or definition.
- `panel` — shaded background region (global only).

Content hierarchy inside a node: **title** (what it is) → **sub** (what it does)
→ **shape** (what flows). Put parameter counts in the small top-right chip only
when they matter to the argument.

## Graph style (operator / tensor)

Use for: the inside of a block, tensor operations, terminal pages.

Node kinds:

- `tensor` — a value with a shape; pale green background.
- `op` — a call; monospace title; neutral background.
- `note` — the "why" box.

Every tensor node gets a `shape` with both symbolic and concrete forms. Every op
gets the exact call name from the code (`torch.bmm`, `F.scaled_dot_product_attention`,
`x.reshape`), not a generic verb. If the op is a method call, keep the receiver:
`q @ k.transpose(-2,-1)` is more useful than "matmul".

## Edges

- Solid, neutral: data flow.
- Accent-colored: a named data family, when the color carries meaning.
- Dashed: detail/reuse, skip connections, or a shared cache.
- Every edge needs a `note`. It is the sentence shown in the inspector.
- Use `via` for orthogonal routing when a straight line would cross a node or a
  label. Keep bends to two or fewer.
- Never route an edge through a node. If the layout forces it, move the node.
- Arrowheads point in the direction of data, not control. For control flow
  diagrams (closed loops), say so in the caption.

## Global view composition

A good global view reads in one pass:

1. **Title** — system name + "Inference Architecture" or the equivalent.
2. **Legend** — only the encodings actually used.
3. **Inputs** — left column, one box per data family.
4. **Stages** — left-to-right, the coarse pipeline.
5. **Outputs** — right column.
6. **Secondary path** — a second panel for the closed loop or offline path.
7. **Footnote** — code refs + the concrete dimensions.
8. **Caption** — one paragraph: what goes in, what comes out, what is interesting.

If the system has two phases (online/offline, train/infer), use two panels with
labels `(a)` and `(b)`, and keep the shared stages visually identical.

## Inspector content

The right-hand panel is the payoff for clicking. Order:

1. title and subtitle;
2. shape (with the symbolic/concrete toggle);
3. parameter count, if known;
4. derivation (`derive`) — why the output has that shape;
5. drill link;
6. note — the caveat or the "why";
7. source snippet with line numbers.

The snippet is not decoration. It is the proof. Keep it short (5–30 lines) and
start it at the line that does the work.

## Readability checks

Before shipping, look at every view and ask:

- Can I read every title without zooming to 150%?
- Does any edge cross a label or run through a node?
- Does any shape line or params chip collide with the title or subtitle?
- Does any node overflow the canvas?
- Is the same data family the same color everywhere?
- Does the inspector snippet actually contain the operation named in the title?
- On the global view, is it obvious which boxes are clickable?

If a screenshot tool is unavailable, open the HTML and zoom to 100% in the
browser; the Fit button should not be the only way to read it.

## Anti-patterns

- A rainbow of accent colors with no meaning.
- 12 nodes in a row with no grouping.
- A "misc" box that hides three subsystems.
- Tensor shapes only in the inspector, not on the canvas.
- Operator pages that are really block diagrams (paper boxes around `torch.*`).
- Decorative icons that do not correspond to a code entity.
