# Spec reference

The spec is plain YAML. The builder is deterministic: same spec + same repo = same HTML.

```
docs/architecture/
├── spec/
│   ├── meta.yaml            # title, palette, sidebar order, shape symbols
│   ├── presets.yaml         # optional: named hyper-parameters
│   ├── templates.yaml       # optional: reusable views
│   ├── glossary.yaml        # optional: terms + plain-language explanations
│   ├── decisions.md         # grill output: scope, branch cut, terminal floor
│   ├── global.yaml          # the global view, as data
│   └── branches/
│       ├── 01_input.yaml
│       ├── 02_core.yaml
│       └── ...
├── assets/                  # optional images used by global nodes
├── explorer.html            # generated
└── architecture.html        # generated
```

Aliases `_presets.yaml` and `_templates.yaml` are accepted, and a legacy
`global_figure.html` + `global_nodes.yaml` + `global_links.yaml` global view is
supported unchanged. New specs should use `global.yaml`.

## meta.yaml

```yaml
title: "Acme Inference Architecture"
repo: "acme"
summary: "One paragraph shown by the 说明 button."
view_canvas: {w: 1600, h: 900}   # default canvas for local views
accents:                          # names → colors; used by node.accent / view.accent
  text: "#6d5fc7"
  video: "#3f7fc4"
  action: "#cf7f34"
  state: "#2f9e6f"
  neu: "#8798ab"
tree: [input, core, output]       # optional; defaults to roots in declaration order
```

`tree` controls the sidebar. If omitted, all views whose `parent: global` are
roots, in branch-file order. Set it when reading order differs from file order.

## presets.yaml

Presets let one spec describe several model sizes or deployment targets. Any
`{name}` in a title/sub/shape is substituted from the active preset; node
parameter counts are computed per preset.

```yaml
default: small
presets:
  small:
    label: "Small · CPU"
    dim: 768
    layers: 12
  large:
    label: "Large · GPU"
    dim: 3072
    layers: 32
```

If the file is absent, the preset selector is hidden and `{name}` placeholders
remain literal. Do not use placeholders you cannot resolve.

## global.yaml

```yaml
title: "Acme Inference Architecture"
subtitle: "全局视图 · 点击带下划线的模块进入局部视图"
plain: "一句话说清整个系统在做什么：谁进来、经过哪几步、最后产出什么。"
plain_terms: [entrypoint, checkpoint]
canvas: {w: 1800, h: 900}

legend:
  - {color: "#6d5fc7", label: "text"}
  - {type: "encoder", label: "stage"}
  - {type: "dash", label: "detail / reuse"}

panels:                            # optional shaded regions
  - {id: p1, label: "(a) Online path", x: 30, y: 80, w: 1100, h: 620, fill: "#f7fbf9"}

nodes:
  - id: input
    kind: card
    accent: text
    title: "Input"
    sub: "what enters"
    x: 50
    y: 170
    w: 220
    h: 92

  - id: core
    kind: enc
    accent: action
    title: "Core"
    sub: "the main transform"
    x: 340
    y: 170
    w: 240
    h: 92
    drill: core                    # must be a view id

edges:
  - {from: input, to: core, note: "what is passed, in one sentence"}
  - {from: core, to: output, note: "what is produced", dash: "7 5"}

footnote:
  columns:
    - {title: "Code refs", text: "src/main.py:12 · src/core.py:40"}
    - {title: "Dims", text: "d=768 · 12 layers · 12 heads"}

caption: "One paragraph: what the system does end to end."
```

Global node kinds:

| kind | shape | use |
| --- | --- | --- |
| `card` | rounded rectangle | an input, output, or ordinary subsystem |
| `enc` | slanted block | an encoder / stage that transforms a data family |
| `strip` | thin bar | one segment of a token sequence or a pipeline lane |
| `inset` | dashed box | a mask, timeline, or other explanatory inset |
| `note` | dashed card | a caveat or definition |
| `panel` | shaded region | a group background; same fields plus `label` |
| `html` | raw markup | escape hatch for a diagram that YAML cannot express |

Any global node also accepts `html:` appended inside it (thumbnails, a small
SVG). `drill` makes the whole box clickable. `shape:` prints a shape chip.

## Branch views

One file per branch. A view is one page. The root view has `parent: global`;
children point at their parent page.

```yaml
views:
  - id: core
    title: "Core"
    subtitle: "what this subsystem does in one line"
    parent: global
    accent: action                 # inherited by children
    style: paper                   # paper for modules/blocks, graph for ops
    canvas: {w: 1600, h: 780}
    source: {file: "src/core.py", line: 40}
    summary: "Why this subsystem exists; its input/output contract."
    vars: {din: 768, dout: 768}    # optional; used by {din} in this view
    code: {file: "src/core.py", start: 40, end: 96}

    nodes:
      - id: x
        kind: card
        accent: text
        title: "x"
        sub: "input features"
        shape: {sym: "B×N×d", real: "B×512×768"}
        x: 60
        y: 180
        w: 200
        h: 90

      - id: mm
        kind: op
        accent: action
        title: "torch.matmul"
        sub: "x @ W"
        x: 340
        y: 180
        w: 220
        h: 90
        drill: core_matmul
        note: "W is [d,d]; the batch dimension is broadcast."

      - id: y
        kind: tensor
        accent: state
        title: "y"
        sub: "result"
        shape: {sym: "B×N×d", real: "B×512×768"}
        x: 660
        y: 180
        w: 200
        h: 90

    edges:
      - {from: x, to: mm, note: "left operand"}
      - {from: mm, to: y, note: "result"}
```

### View fields

| field | required | meaning |
| --- | --- | --- |
| `id` | yes | unique; lowercase snake_case; referenced by `drill` and `parent` |
| `title` | yes | short label; may use `{preset}` / `{var}` placeholders |
| `subtitle` | no | one line under the title in the inspector |
| `parent` | no | parent view id; default `global` |
| `accent` | no | color name or `#hex`; inherited by children |
| `style` | no | `paper` (default) or `graph` |
| `canvas` | no | `{w, h}`; default from `meta.view_canvas` |
| `source` | no* | `{file, line}`; the page's main code pointer |
| `code` | no* | `{file, start, end}`; snippet shown by the 说明 button |
| `summary` | no | why the page exists, shown in the inspector |
| `plain` | no | one jargon-light sentence; shown in the 人话 bar and the 说明 panel |
| `plain_terms` | no | glossary term ids to show as chips beside the plain sentence |
| `vars` | no | local values for placeholders/calc |
| `inherits` | no | `stack` = inherit vars from the previous view in the path |
| `terminal` | leaves | true when the page ends at a primitive |
| `terminal_reason` | no | why a terminal page has no snippet (generated code) |
| `nodes` | yes | list of nodes |
| `edges` | no | list of edges |
| `extends` | instances | template view id |
| `template` | templates | true marks a reusable template |

*Every non-terminal page should have `source` or `code`. Every leaf must have
`code` or an explicit `terminal_reason`.

### Node fields

| field | meaning |
| --- | --- |
| `id` | unique within the view; used by edges and `drill` |
| `kind` | `card`, `enc`, `strip`, `note`, `tensor`, `op`, `table` |
| `param_state` | `train` / `frozen` / `n-a` — whether this node's weights move |
| `param_when` | the configuration the `param_state` claim is about (e.g. `LoRA 配置`) |
| `cols`, `rows`, `key` | `kind: table` only — see “Parameter ownership” |
| `accent` | palette name or hex |
| `title`, `sub` | label and one-line explanation |
| `term` | explicit glossary id for the “人话” note; otherwise inferred from the title |
| `shape` | `{sym, real}` — symbolic and concrete; the Symbolic button flips them |
| `x`, `y`, `w`, `h` | absolute layout in the canvas |
| `drill` | target view id; makes the node clickable |
| `note` | longer explanation for the inspector |
| `derive` | how the output shape/value follows from the input |
| `code` | `{file, start, end}` for this node |
| `source` | `{file, line}` alternative to `code` |
| `calc` | parameter-count recipe (below) |
| `params` | literal `{preset: count}` override |
| `flush` | true removes internal padding (containers) |
| `html` | raw markup appended inside the node |

`kind: note` is the callout kind. It may carry `drill` to a detail page and
must not appear in `edges`: a note is an annotation, not a stage. This is the
right way to expose "FFN inside the block" or "the pre-norm site" without
claiming that data flows from the block into them.

`drill` alone does not imply an edge. A drillable node with no edges is a
callout; give it `kind: note` so the drawing and the checks agree.

### Edges

```yaml
edges:
  - {from: a, to: b, note: "what moves"}
  - {from: a, to: b, accent: action, dash: "6 4", note: "..."}
  - {from: a, to: b, via: [[400,300],[400,200]], note: "orthogonal routing"}
  - {d: [100,200, 300,200, 300,400], note: "explicit polyline"}
```

`from`/`to` must be node ids in the same view. `via` points are absolute
coordinates; the endpoints are snapped to the node borders. `d` is a flat list
of `x,y` pairs and is drawn as-is. Every edge must have a `note` that names
the value that moves.

**An edge means data flow, not containment.** The reader sees an arrow and
infers "the output of A is an input of B". If the truth is only "B is a part of
A" or "B opens A's detail page", the edge is a false claim. This is the single
most common way a plausible-looking diagram becomes wrong.

It is also easy to miss mechanically: both endpoints exist, the detail views
are reachable, and every node has a title, so a syntax-only check passes. The
old validator could not distinguish a data edge from a containment edge; the
checks below now reject the two shapes that produce this error. The lesson is
not "draw fewer arrows" — it is "use the callout kind when the relation is
inside/detail, and read the return statement before drawing the outputs".

#### Containment is a callout, not an edge

A repeated block (`18× Block`, a layer loop, `nn.scan`, a `ModuleList`) owns
its internals. Attention, FFN, and the pre-norms happen **inside** the
repetition; they are not stages after it.

```yaml
nodes:
  - id: blk
    kind: enc
    title: 18× Transformer block
    drill: block_internals

  # A callout: drillable, deliberately unconnected.
  - id: ffn
    kind: note
    title: Block 内部的 FFN（点开）
    sub: 每个 expert 独立
    drill: block_ffn

  - id: pre_norm
    kind: note
    title: Block 内部的 pre-norm（点开）
    drill: block_adarms

edges:
  - {from: tokens, to: blk, note: "the token stream entering the stack"}
  - {from: blk, to: final_norm, note: "the stream returned by the stack"}
# no edge blk -> ffn, no edge blk -> pre_norm
```

A `kind: note` may carry `drill`. That makes it a callout to a detail page and
is the correct way to expose an internal component. It must not appear in
`edges`. An unconnected callout is not an orphan; an orphan **view** is the
error, and the `drill` already makes the view reachable.

#### Multi-stream returns

Read the function's return before drawing its outputs. A signature that returns
`list`, `tuple`, or `Sequence` of per-expert tensors has several streams, not
one tensor that splits.

```python
# gemma.py: Module.__call__
return [f(e, a)[0] for f, e, a in zip(self.final_norms, embedded, adarms_cond)]
```

```yaml
# The block returns [prefix, suffix]; draw two labelled lanes.
edges:
  - {from: block, to: norm_prefix, note: "return[0] — prefix stream"}
  - {from: block, to: norm_suffix, note: "return[1] — suffix stream"}
```

Do not draw one output box with two arrows and call it a split. Give each
stream its own final norm, because `final_norms` is a per-expert list and the
`adarms_cond` can differ by stream (plain RMSNorm vs adaptive RMSNorm). A
single norm node is then wrong twice: it does not name the stage, and it has
the wrong cardinality.

#### Norms must name their site

`RMSNorm` appears at least three times in a transformer: before attention,
before the FFN, and once at the end. A node titled only "RMSNorm / adaRMS" is a
catch-all. Put the site in the title or `sub`:

```yaml
- {id: pre_attn_norm, title: "pre-attention norm", sub: "RMSNorm"}
- {id: pre_ffn_norm,  title: "pre-FFN norm",       sub: "RMSNorm"}
- {id: norm_prefix,   title: "final_norm · prefix", sub: "plain RMSNorm"}
- {id: norm_suffix,   title: "final_norm · suffix", sub: "adaRMS in π0.5"}
```

#### Flow audit before validating

For each view, read the `source`/`code` and answer:

1. What is the return type and what does the `return` statement actually
   produce? (`list`/tuple → parallel lanes.)
2. For every edge, which argument, return element, or assignment carries
   `from` into `to`? If there is no line, delete the edge.
3. Is `from` a repeated container? If yes, its internals are callouts, not
   downstream stages.
4. Does every norm name its site and its stream?
5. Are callouts left unconnected? They should be.

`check.py` **rejects** the two false-flow forms: an edge touching a
`kind: note`, and an edge out of a repeated container into an internal part
(FFN / norm / attention). It warns on a drillable node with no edges that is
not a note, and on an RMSNorm/adaRMS node that never names pre-attention /
pre-FFN / final.

### calc recipes

Parameter counts are optional, but when present they must be computed, not
typed. Supported `type` values:

| type | fields | formula |
| --- | --- | --- |
| `linear` | `din, dout` | `din*dout + dout` |
| `linear_pair` | `d1, h` | `d1*h + h + h*d1 + d1` |
| `linear_pair_gate` | `d1, h` | `3*d1*h` |
| `cs_linear` | `cats, din, dout` | `cats*(din*dout + dout)` |
| `conv2d` | `cin, cout, k` | `cout*(cin*k*k) + cout` |
| `conv3d` | `cin, cout, kt, kh, kw` | `cout*(cin*kt*kh*kw) + cout` |
| `embedding` | `vocab, dim` | `vocab*dim` |
| `expr` | `expr` | arithmetic over preset keys |

```yaml
calc: {type: linear, din: "dim", dout: "ffn_dim"}
```

Values are evaluated per preset; use the preset key name (`dim`), not `{dim}`.

## Parameter ownership (trainable vs frozen)

A training branch that never says *which* weights move is unfinished. "We
finetune the model" hides the difference between a full finetune and a LoRA
run, and that difference lives in a filter — not in the model diagram, and not
in the config's name.

**The claim is always conditional.** `pa_config.get_freeze_filter()` returns
different filters per variant, so "frozen" without a config is a false
universal statement. The matrix exists to carry the condition; the badge exists
to point at the matrix.

### `kind: table` — the matrix

One row per **distinct freeze expression**, not per config name. Eighteen
configs that all leave `freeze_filter` at `nnx.Nothing` are one row with
their names in `sub`, not eighteen identical rows.

One column per **weight group**. Split a group as soon as it is partly frozen:
a LoRA run freezes the base kernel and trains the adapter, so "the LLM" is two
columns, not one cell with a question mark.

```yaml
- id: params
  kind: table
  accent: state
  title: 可训练参数归属
  sub: 每一行是一个不同的 freeze 表达式，不是一条 config
  x: 60
  y: 150
  w: 1240
  h: 300
  key: "绿 = 进梯度并更新 · 灰 = 冻结（bf16、无 opt_state） · — = 该配置下不存在"
  cols: ["Gemma 2B base", "Gemma 2B LoRA", "action expert base", "action expert LoRA"]
  rows:
    - label: 全量微调
      sub: pi0_aloha / pi05_droid / …（默认 nnx.Nothing）
      ref: "src/openpi/training/config.py:493"
      cells: [train, train, train, train]
    - label: LoRA
      sub: pi0_libero_low_mem_finetune
      ref: "src/openpi/models/pi0_config.py:115"
      cells: [frozen, train, frozen, train]
    - label: Pi0FAST LoRA
      sub: pi0_fast_libero_low_mem_finetune
      ref: "src/openpi/models/pi0_fast.py:129"
      cells: [frozen, train, {mark: "n-a"}, {mark: "n-a"}]
```

Rules:

- **`ref` is required on every row.** It is the line that decides that row —
  the `freeze_filter=…` in the registry, or the `return` of
  `get_freeze_filter`. `check.py` resolves it against the repo and errors if
  the file or line does not exist.
- `cells` must be one per column. A cell is `train`, `frozen`, `n-a`, or
  `{mark: …, text: "…"}` when a qualifier is needed.
- `expr` (optional) is the filter expression itself. It is clipped to one line
  and shown in full on hover; it belongs next to the row, not only in the prose.
- `n-a` means the module does not exist in that configuration (no action expert
  in a single-tower model, no adapter in a full finetune). It is not the same as
  `frozen`, and deleting the column is usually better than a row of `n-a`.
- `key` explains the marks. Colour alone is not an explanation.
- A table is evidence, not a stage: no edge may touch it, and it carries no
  `drill` unless it opens a finer breakdown.

### `param_state` — the badge

Put the tag on nodes whose weights the reader is likely to assume wrong — the
frozen vision tower, the adapter that is the only thing training, the
projection heads that always train.

The destination is declared once per view, not once per node, because a node
usually already drills into its own detail page:

```yaml
- id: vision
  param_matrix: training_params      # view id of the kind: table matrix
  nodes:
    - id: sig
      kind: card
      title: SigLIP So400m/14
      param_state: train
      param_when: 所有 config
      drill: vision_block           # still opens the module's own page
```

The badge itself carries `data-drill` to the matrix, so clicking the label
opens the table while clicking the node keeps opening its detail page.

- `param_state` must be `train`, `frozen`, or `n-a`; anything else is an error.
- A view with any `param_state` tag **must** declare `param_matrix`, and the
  target must be a `kind: table` view. A tag with no destination is an
  unsupported claim.
- `param_when` names the configuration. Without it the tag reads as "always",
  which is exactly the mistake this feature exists to prevent; `check.py`
  warns when the matrix has more than one row and the tag is unqualified.
- Do **not** tag a node that mixes states. If attention holds both a frozen
  kernel and a trainable adapter, the node is not taggable — split it in the
  matrix and use a `kind: note` callout on the diagram.

## Glossary and plain language

The explorer has a beginner layer that is entirely optional and entirely
data-driven. Without `glossary.yaml` (and without `plain:` fields) it is
invisible: same HTML, same layout, no extra buttons.

Add it when the reader knows how to program but not this domain. The layer has
three surfaces, all fed by the same file:

1. **名词解释 (G)** — a searchable modal with one card per term.
2. **Inline terms** — the first occurrence of a term in a node title gets a
   dotted underline and a `?`; hover shows a one-sentence tooltip, click opens
   the card.
3. **人话 bar** — the current view's `plain` sentence, always visible above the
   canvas, with up to four `plain_terms` chips.

```yaml
# glossary.yaml
title: 名词解释
subtitle: 先懂这些词，再看图。
categories: [核心概念, 实现细节]     # card order; omit to use first-seen order

intro:                                # optional two-column primer in the modal
  - {term: "req", tag: "输入", text: "外部请求从这里进入"}
  - {term: "res", tag: "输出", text: "最终返回给调用方的结果"}

terms:
  - id: checkpoint                  # stable id used by plain_terms / node.term
    term: checkpoint                # display name
    zh: 存档                        # optional Chinese gloss, shown next to it
    category: 核心概念               # must be in categories, or it is appended
    core: true                      # star + sidebar chip (keep 4-8)
    plain: 训练得到的参数和归一化统计量的存档，是训练和推理之间唯一的交接物。
    detail: 训练脚本定期写入 params 与 norm_stats；推理时读同一份，参数或统计量对不上动作就会偏。
    analogy: 像游戏存档：训练时写档，推理时读档。
    aliases: [checkpoint, checkpoints, 存档]   # auto-linking; longest alias wins
    views: [training_ckpt, policy_config]       # "在图中" jump targets
```

Rules:

- `plain` is one sentence, no unexplained jargon. It is the sentence a reader
  should be able to repeat.
- `detail` is where precision lives: shapes, formulas, edge cases. It renders
  collapsed behind “再深入一点”.
- `analogy` must not introduce a second technical concept. If it needs a
  footnote, it is not an analogy.
- `aliases` are matched case-insensitively. Include plural / hyphenated forms
  that actually appear in titles; do not add generic words like “the”.
- `views` ids must exist; `global` is always valid.
- `plain_terms` on a view must reference a term id in this file. `check.py`
  enforces both directions.
- 8-30 terms for a medium repo. A glossary that defines every noun trains the
  reader to ignore it.

The text is part of the spec, so it is reviewed like the diagram: no invented
behavior, and every claim still has a code pointer in the view or node.

## Shape symbols and einsum

A shape like `B×T×K×G×H` and an expression like
`BTKGH,BSKH->BKGTS` are the most compressed notation on the page. They are
also the easiest place to lose a reader: six letters can carry the whole GQA
story. Every letter printed on the canvas must be defined, and the definition
must say what the letter counts, not just expand the acronym.

Symbols live at two levels and merge at render time:

```yaml
# meta.yaml — applies to every view
symbols:
  B: {name: batch, zh: 批大小, detail: "一次并行处理多少条样本；训练时是几十，部署时通常为 1。"}
  T: {name: target length, zh: 目标长度, detail: "当前 query 的 token 数，也就是这一层要产出多少个位置。"}
  S: {name: source length, zh: 源长度, detail: "被注意的 key/value token 数；自注意力里通常等于 T，交叉注意力里是另一段序列。"}
  D: {name: model width, zh: 模型宽度, detail: "每个 token 的向量维数；两个 expert 的宽度可以不同。"}
  N: {name: query heads, zh: query 头数, detail: "把 D 切成多少个查询头；每个头独立算注意力。"}
  K: {name: kv heads, zh: KV 头数, detail: "key/value 的头数。GQA 下 K < N，多组 query 共享一组 K/V。"}
  G: {name: query groups, zh: 组数, detail: "每个 KV 头对应的 query 头数，G = N/K。"}
  H: {name: head dim, zh: 头维, detail: "单个注意力头的宽度；输出宽度不变时 N×H = D，若投影改变了宽度则以代码为准。"}
```

```yaml
# branches/attention.yaml — only where a letter changes meaning
views:
  - id: attention_scores
    symbols:
      K: {name: kv heads, zh: KV 头数, detail: "这里只算 K 个头，不是层数。"}
```

A value can also be a plain string, which becomes `detail`:

```yaml
symbols:
  B: "一次并行处理多少条样本；部署时通常为 1。"
```

### What gets linked

The builder annotates two contexts, and only those:

1. **Shape chips** — `B×T×D`, `B×T×8×256`, `BTKGH`. A single letter is a
   symbol; an all-uppercase run is split into one symbol per letter; a longer
   token such as `d_model` or `float32` is not treated as symbols.
2. **Arrow expressions** — anything matching `A,B->C` in a node title or
   `sub`, including several expressions separated by `·`. Digits and `,`
   stay literal; every letter is wrapped.

Letters with a definition get a dotted underline, a hover tooltip, and a link
to the 符号说明 table. Letters without a definition stay plain, and `check.py`
emits a warning naming the view and the missing letters.

### UI surfaces

- **符号 button / `S`**: a table of all symbols available to the current view,
  with used letters marked `本层`. Each row has the letter, English name,
  Chinese gloss, and the detailed meaning.
- **Inline hover**: the letter + name + detail, positioned next to the cursor.
- **Inspector**: a "符号" block on node and global-node panels listing only the
  letters used by that node; the 说明 panel lists the view's used symbols.

### Rules

- Every letter in a shape or `->` expression has a definition, either global
  or in that view.
- The definition says **what it counts** and, when two letters are easy to
  confuse, **how they relate**: `G = N/K`, `N×H` vs `D`, `B` vs `T`.
- Use `detail` for the sentence you want a reader to remember; `name`/`zh` are
  labels, not explanations.
- Define per view when a letter means something local (a `K` that is a head
  count in one view and a kernel size in another). The override replaces the
  global value for that view only.
- Do not invent dimensions to make a symbol table look complete. If the code
  does not name a dimension, leave the shape concrete (`1×816×2048`) instead of
  introducing a letter.
- Literals such as `2` in `2BSKH` (stacked key/value) and `8` in
  `B×T×8×256` need a note in the node's `sub` or `note`; they are not symbols.

## Templates and reuse

```yaml
# templates.yaml
views:
  - id: category_linear
    template: true
    title: "CategorySpecificLinear"
    style: graph
    canvas: {w: 1400, h: 720}
    vars: {din: 128, dout: 256}
    nodes: [...]
    edges: [...]
    code: {file: "src/layers.py", start: 31, end: 42}
```

```yaml
# branches/core.yaml
views:
  - id: w1
    extends: category_linear
    title: "W1 ({din}→{dout})"
    parent: core
    vars: {din: 32, dout: 768}
```

Instances inherit everything and override what they name. Use reuse for
operators with the same implementation; give semantically different variants
(masked softmax, causal conv) their own page.

## Code references

```yaml
source: {file: "src/core.py", line: 40}
source: "src/core.py:40"          # same thing
code: {file: "src/core.py", start: 40, end: 96}
code: "src/core.py:40-96"
```

Paths are relative to the repo root (auto-detected via `git rev-parse`, else the
third parent of `docs/architecture/spec`). The builder copies the exact lines
into the HTML and fails if a file or line does not exist. The snippet is the
evidence; do not paraphrase it.

## Legacy global view

`global_figure.html` + `global_nodes.yaml` + `global_links.yaml` is supported so
the DreamZero spec builds unchanged. New specs should use `global.yaml`: it is
shorter, and the builder can check its ids and bounds.
