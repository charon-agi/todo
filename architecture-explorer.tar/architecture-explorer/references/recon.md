# Recon and tracing

The goal is not to summarize the repo. It is to answer: **what runs, in what
order, on what shapes, and where does the computation actually happen?**

## 1. Find the entrypoint that matters

Read, in order:

1. `README.md` — the "usage" and "architecture" sections.
2. `pyproject.toml` `[project.scripts]`, `package.json` `main/bin/scripts`,
   `Cargo.toml` `[[bin]]`, `go.mod` + `package main`, `Dockerfile` `CMD`.
3. The conventional entry files: `main.py`, `app.py`, `server.py`, `cli.py`,
   `train.py`, `infer.py`, `src/index.ts`, `cmd/*/main.go`.
4. `if __name__ == "__main__"` / `func main` / `static void main`.

Then choose **one** primary path. A repo often has several:

- training vs inference vs evaluation;
- server vs client;
- CLI vs library.

Pick the path the user cares about. If unclear, pick the one the README uses in
its first example. Mention the others as branches only if they change the model.

Do not trust `recon.py`'s candidate list blindly; test scripts and demos often
outnumber the real entrypoint.

## 2. Trace the runtime path

Start at the entrypoint and follow calls, not imports. At each step record:

- the function and its `file:line`;
- the input and output shapes/types (from annotations, asserts, configs, or the
  actual tensor construction);
- whether the step is in-repo (keep going) or a library/runtime primitive (stop).

Useful searches:

```bash
rg -n "def (forward|__call__|main|run|encode|decode|step|handle)" <path>
rg -n "class .*\((nn\.Module|Module|Layer|Model)\)" <path>
rg -n "@(app|router)\.(get|post|put|delete)|add_route|HandleFunc" <path>
rg -n "matmul|einsum|bmm|conv|softmax|attention|linear|relu|gelu|silu" <path>
rg -n "assert .*shape|assert .*dim|\.shape\[|reshape|view\(" <path>
```

Python ML repos: the real model is usually reachable from
`Model.__init__` + `forward`; configs in `configs/*.yaml` give the constants.
Do not read the whole repo — read the path and one representative variant.

## 3. Decide the branch decomposition

A branch is a **data family or a pipeline stage**, not a directory.

Good branch cuts:

- one per encoder (text / image / video / action / state);
- one per major stage (preprocess / backbone / head / postprocess);
- one per runtime path (online / offline / training) when they diverge;
- one per external boundary (HTTP layer / DB layer) for services.

Bad branch cuts:

- one per file;
- one per class;
- "utils", "common", "misc".

Aim for 5–10 branches. If you have 20, merge siblings; if you have 3, you are
probably hiding a subsystem inside a box. If none of these cuts fit the repo,
stop and run the grill (`references/grilling.md`) instead of forcing a list.

## 4. Depth: when to stop

Stop at the first layer outside the repo:

- Python ML: `torch.nn.functional.*`, `torch.*`, a CUDA kernel launch, a
  tokenizer call, a file/network read.
- Web: the ORM query, the template render, the HTTP client call, the cache call.
- CLI: the stdlib file/JSON/argparse boundary.
- Compiler: the IR builder/visitor call that performs the rewrite.

For each terminal page, show:

1. the operands and their exact shapes;
2. the primitive call (name it as the code names it);
3. the result shape;
4. the one semantic detail that is easy to get wrong (axis, mask, dtype,
   broadcast, padding, layout, in-place).

If a primitive is wrapped in a helper, open the helper. If the helper is a
one-line delegation, the terminal page can cite the delegation and the callee.

## 5. Shapes and constants

Never guess. Sources, in order of trust:

1. tensor construction and `.reshape/.view/.permute` calls;
2. `assert` statements and `einops` strings;
3. type hints / dataclass fields;
4. config YAML/TOML values;
5. default arguments.

If two presets exist, put the constants in `presets.yaml` and reference them by
name. If a shape depends on input length, write both the symbolic and concrete
forms: `shape: {sym: "B×T×d", real: "B×48×5120"}`.

## 6. Evidence rules

- Every claim in a title, `sub`, `note`, or `derive` must be supported by a line
  in the repo. If it is a reasonable inference, write `推断:` and keep it short.
- Do not describe behavior the code does not have. The classic failure is
  "clipped/tanh/normalized" on an output that is returned raw.
- Do not copy comments as truth; comments drift. The executable line wins.
- If a code path is dead or disabled (commented out, `if False`), do not draw it
  as active. Mention it in a note if it explains a missing step.
- Parameter counts must be computed from the layer definitions, not remembered.

## 7. Coverage checklist

Before building, confirm:

- [ ] every top-level stage in the global view has a drill;
- [ ] every non-trivial box in every module view has a drill;
- [ ] every leaf is a primitive, not another in-repo function;
- [ ] every view has at least one code pointer;
- [ ] every edge has a one-sentence note;
- [ ] every shape has a source (code/config), not a guess;
- [ ] no view is unreachable from the sidebar;
- [ ] a reader can go global → branch → block → primitive without a dead end.
