---
name: architecture-explorer
description: Build a drill-down architecture explorer (explorer.html) for any repository — entrypoint → modules → blocks → primitive operations, every claim tied to file:line. Grills the exploration plan first when the repo resists a fixed taxonomy. Use after git clone when asked to analyze a repo's architecture, produce an architecture walkthrough / 架构走读 / explorer.html, or explain how a codebase actually computes.
---

# Architecture Explorer

Produce two artifacts inside the target repo:

- `docs/architecture/explorer.html` — interactive: global view → branch → block → primitive, with breadcrumbs, a structure tree, a source inspector, and an optional plain-language layer (名词解释 glossary, inline `?` terms, 人话 bar).
- `docs/architecture/architecture.html` — the same global view as a static figure.

The spec lives in `docs/architecture/spec/`; rebuilding is one command.

This is an **analysis** task that happens to end in HTML. The HTML is not the deliverable if the code reading is shallow.

## Non-negotiables

1. **Every view and every node carries evidence.** A `file:line` pointer and a code snippet copied from the repo. If a statement is inferred rather than read, prefix it with `推断:` and keep it out of the main claim.
2. **Every branch bottoms out at a primitive.** A terminal node is a call into a third-party library or a language/runtime primitive — `torch.bmm`, `F.relu`, a SQL statement, an HTTP handler, a DOM write. "It calls another in-repo function" is not terminal; open that function and keep going.
3. **Every view is reachable.** No orphan pages. Every non-root view is either in `meta.tree` or the target of a `drill`.
4. **Two visual languages, never mixed.** Module/block views use the paper style. Tensor/operator views use the graph style. The change of vocabulary is what tells the reader they descended a level.
5. **Do not invent shapes, constants, or behavior.** Shapes come from tensor operations, type hints, configs, or assertions. If the repo does not state it, do not print it.
6. **Every shape symbol is defined.** A shape like `B×T×K×G×H` or an expression like `BTKGH,BSKH->BKGTS` is unreadable until each letter says what it counts. Define every letter in `meta.symbols` (or a view's `symbols:` when the meaning is local), including the relations that disambiguate it (`G = N/K`, why `N×H` can differ from `D`). A page with an undefined letter is unfinished.
7. **An edge is data flow, never containment or navigation.** `from` must actually be passed into `to` on a line you can cite. "FFN is inside this block", "this norm modulates the block", and "click here for the detail page" are not edges. Use a `kind: note` callout with `drill` and leave it unconnected. An edge that only means "belongs to" is a false claim about the computation.

8. **A training path names the weights that actually move.** If the walkthrough
   covers finetuning, it carries a parameter-ownership matrix: one row per
   **distinct freeze expression** (not per config name), one column per weight
   group, and a `ref` to the line that decides each row. "Frozen" with no
   configuration attached is a false universal claim — the filter is an argument
   of the variant, not a property of the model.

## Definition of done

- Global view: 3–12 stages, every arrow has a one-sentence note, every drillable stage has a view.
- Branches: 3–10 top-level branches; 25–60 views total for a medium repo, fewer for a small one. Padding is a defect.
- Leaves: 100% marked `terminal: true` and backed by a code snippet (or an explicit `terminal_reason` when the primitive is generated code).
- `spec/decisions.md` exists, contains no `TODO`, and records scope, branch cut, and terminal floor.
- `spec/glossary.yaml` exists, every term has a one-sentence `plain`, and every view has a `plain` line; the 名词解释 / 人话 layer opens and searches.
- Every letter used in a shape chip or `->` expression is defined in `meta.yaml` or the view; the 符号 table (or `S`) lists it and inline letters show the same meaning.
- Every edge describes a value that actually moves, and its note names that value; no edge touches a `kind: note`, and no repeated container (loop / scan / 18× block) points at an internal detail.
- Training coverage: a `kind: table` matrix exists with one row per distinct
  freeze expression, every row cites its `freeze_filter` line, every view that
  carries a `param_state` badge declares `param_matrix`, and no badge sits on a
  node that mixes frozen and trainable weights.
- Every RMSNorm/adaRMS node names its stage (pre-attention, pre-FFN, final); a function that returns `[prefix, suffix]` has one final norm per lane, not one shared norm.
- `check.py` reports **0 errors**. Every remaining warning is understood and acceptable.
- `build.py` writes both HTML files; you have opened at least the global view and one leaf and clicked through them.
- The final report gives absolute paths and the view/branch counts.

## Workflow

### 1. Recon — find the real entrypoint

```bash
python3 ~/.codebuddy/skills/architecture-explorer/scripts/recon.py --repo <repo>
```

Read the generated `docs/architecture/recon.md`, then verify it against the README and build files. Entrypoint candidates are candidates, not truth — test scripts and demos often dominate the list.

**Completion criterion:** you can name, with `file:line`, the entrypoint, the 3–7 major subsystems it reaches, and the end-to-end data flow in one paragraph. If you cannot, you are not ready to draw.

### 2. Grill the exploration plan

The default pipeline assumes one runtime path and a branch per data family or stage. That is wrong for monorepos, plugin hosts, compilers, data pipelines, notebook repos, and thin SDKs. Interview before committing to a shape.

This step is a specialization of the `grilling` / `grill-me` skill. If `grilling` is installed, load it for the protocol; the design tree and question bank in `references/grilling.md` take precedence.

Build the design tree, then ask the **frontier** — one question per round, because this user prefers one decision at a time. Give a recommended answer and wait. Facts are your job (`recon.py`, code reading); decisions are the user's.

Settle at least:

- runtime path and scope (what is in, what is explicitly out);
- branch cut (data family / stage / deployable / extension point);
- terminal floor for this domain;
- depth allocation and view budget;
- evidence standard for configs, generated code, vendored code;
- parameter ownership, if the path is training (row axis, column axis, evidence
  for the freeze decision);
- audience, language, visual style.

Write the answers to `spec/decisions.md`. A straightforward repo needs one round; a repo that resists the taxonomy needs several.

**Completion criterion:** `spec/decisions.md` has no TODO, every branch of the design tree is settled, and the user confirms the assumptions. Do not scaffold or draw before this.

### 3. Scaffold and blueprint the global view

```bash
python3 ~/.codebuddy/skills/architecture-explorer/scripts/init_spec.py --repo <repo>
```

Replace the demo stages in `spec/global.yaml`. The global view is the whole system on one screen: inputs on the left, stages left-to-right, outputs on the right, side inputs below or above. Every stage that deserves its own page gets `drill: <view-id>`.

**Completion criterion:** every box is a real subsystem, every arrow is a real data dependency with a sentence explaining what moves, and every drill id is planned.

### 4. Analyze each branch, top-down

For each branch, write one file `spec/branches/<branch>.yaml`. Work in three passes:

1. **Module view (paper).** 4–9 nodes. This is the block diagram of the subsystem: inputs, the big blocks, the output. Each non-trivial block gets `drill`.
2. **Block views (paper).** One per non-trivial block. Show the actual sequence of operations and the shape change at each step.
3. **Terminal views (graph).** One per distinct primitive. Show operands → call → result, with the exact shape. Annotate broadcast, masking, dtype, layout, or axis order when the code depends on it.

Reuse a terminal view via `extends` when several call sites share the same primitive (see `references/spec.md`). Special-case only when semantics differ (masked softmax, causal conv, fused kernel).

**Parameter ownership pass.** Before drawing a training branch, answer: which
weights does the optimizer update? Read the freeze filter, not the config name.
Then write one `kind: table` view:

- one row per **distinct freeze expression**; put the config names in the row's
  `sub`, never one row per name;
- one column per weight group, split whenever a group is partly frozen (base
  kernel vs LoRA adapter is the common case);
- a `ref` per row: the `freeze_filter=…` in the registry or the `return` of
  `get_freeze_filter`;
- `train` / `frozen` / `n-a` cells, plus a `key` that defines the marks.

Badge the diagram with `param_state` + `param_when`, set `param_matrix` on the
view, and only tag nodes whose weights are uniform. A node holding both a
frozen kernel and a trainable adapter cannot be tagged; put a `kind: note`
callout on it instead. Record the scope choice in `decisions.md` under 参数归属.

**Completion criterion per branch:** every leaf is a primitive with a code pointer; every shape can be derived from the code/config; no node says "does X" without a line that does X.

### 5. Write the plain-language and symbol layer

The diagram is for someone who can read code but does not know this domain yet. Add the explanation layer after the structure is correct, never before — otherwise the prose hides an unverified diagram.

Two vocabularies need definitions: domain words (glossary) and shape letters (symbols).

Start from `assets/templates/glossary.yaml` and write `spec/glossary.yaml`:

- 8–30 terms, chosen by "what stops a newcomer on this page", not "every noun".
- Mark 4–8 of them `core: true` so they appear in the sidebar.
- Each term: `plain` (one sentence, no unexplained jargon), `analogy`
  (optional, shorter than `plain`), `detail` (shapes, formulas, edge cases),
  `aliases` (forms that actually appear in titles), `views` (jump targets).
- Give every view a `plain:` sentence and 2–4 `plain_terms:`; do the same for
  `global.yaml`. These feed the 人话 bar and the 说明 panel.

Then define the shape alphabet in `meta.yaml` under `symbols:` (or in a view's
`symbols:` when the letter means something local there). For every letter:

- say **what it counts** (`T` = query tokens, not "sequence length" in general);
- give the relation to its neighbours when the notation depends on it
  (`G = N/K`, `N×H` vs `D`, `K` vs `N`);
- put literals such as `2` in `2BSKH` or `8` in `B×T×8×256` in the node's
  `sub`/`note`, because they are not symbols.

The renderer links letters only inside shape chips and `...->...` expressions,
so do not expect arbitrary prose letters to be explained.

Then reread the diagram through the glossary: any term used in a `plain` sentence
must either be defined in the glossary or be ordinary programming vocabulary. The
inline `?` markers should land on the terms a newcomer is most likely to skip.

**Completion criterion:** every non-leaf view has `plain`; every glossary term
has `plain`; every letter in a shape or `->` expression has a definition; no
`plain` sentence introduces a term that neither the glossary nor ordinary
programming covers; `check.py` reports no glossary or symbol warnings.

### 6. Audit the flow against the code

Before validating, reread the `source`/`code` of each view and answer these questions. This is a separate pass on purpose: the drawing pass reads structure, the audit pass reads data movement.

1. **What does the function return?** Read the signature and the actual `return`. A `list`, tuple, `Sequence`, or `[prefix, suffix]` means multiple streams. Draw one lane per stream; a single block with several outgoing arrows is not the same thing.
2. **For every edge, which line passes `from` into `to`?** If you cannot name an argument, return element, or assignment, the edge is false. Delete it and use a callout.
3. **Is `from` a container?** `nn.scan`, a layer loop, `ModuleList`, or a title like `18× block` means its internals (attention, FFN, pre-norm) are **inside** the repetition. They are not downstream stages. Put them in a block-internals view and reach it through a `kind: note` callout.
4. **Which norm is this?** Pre-attention, pre-FFN, and final norm are different sites with different inputs. Never use one node for "the norm"; name the site, and when norms are per-stream, give each stream its own node.
5. **Are the callouts unconnected?** A `kind: note` node with `drill` and no edges is valid and honest. Do not invent an edge to make it look attached.

**Completion criterion:** every edge has a citable data path; no edge touches a note; no repeated container points at an internal detail; every norm names its stage and lane; `check.py` reports no flow errors or warnings.

### 7. Validate

```bash
python3 ~/.codebuddy/skills/architecture-explorer/scripts/check.py \
  --spec <repo>/docs/architecture/spec --repo-root <repo>
```

Fix every error. Read every warning; either fix it or justify it in the final report. The most common real defects are orphan views, leaves that stop at an in-repo function, and code ranges that no longer match the file.

**Completion criterion:** 0 errors, and no unexplained warning.

### 8. Build and inspect

```bash
python3 ~/.codebuddy/skills/architecture-explorer/scripts/build.py \
  --spec <repo>/docs/architecture/spec --out <repo>/docs/architecture
```

Open `explorer.html`. Check: the global figure fits, drills land on the right view, the inspector shows source, edges do not cross labels, and the sidebar tree has no missing branches.

If `glossary.yaml` exists, also check the explanation layer: the 人话 bar appears on views that define `plain`, the 名词解释 button (or `G`) opens the overlay, search filters by term/Chinese/prose, an inline `?` opens the matching card, and a "在图中" link closes the overlay and lands on the right view. A glossary card whose jump target is wrong is worse than no card.

If `symbols:` is defined, check the 符号 button (or `S`): every letter in the current view's shapes and einsum expressions opens a row with its full meaning, used letters are marked, and hovering a letter in a shape or expression shows the same name/detail. A letter that renders without an underline is undefined.

Re-read the flow once more in the rendered page: an edge that only expresses "this part belongs to that block" is visible as an arrow running from a container to a callout. There should be none.

If a local browser is available, capture the pages instead of eyeballing them:

```bash
python3 ~/.codebuddy/skills/architecture-explorer/scripts/shot.py \
  --html <repo>/docs/architecture/explorer.html \
  --out /tmp/shots --views global,<branch>,<leaf>
```

The helper uses Chromium if present, else Firefox, and moves the page under the
home directory because the Firefox snap cannot read `/tmp` or hidden folders.

**Completion criterion:** the click path global → branch → block → primitive works without a dead end, and each screenshot shows a readable canvas (no clipped nodes, no edges through labels).

### 9. Deliver

Report absolute paths (`explorer.html`, `architecture.html`, `spec/`), the branch/view/leaf counts, and any claim you had to mark as inferred.

## Depth by repository type

| Repo type | Terminal level | What the leaf must show |
| --- | --- | --- |
| ML model / inference | framework op | operands, shapes, axis, mask/dtype, parameter count |
| ML training / finetuning | optimizer update | freeze filter, `opt_state` membership, dtype of frozen params, which config the claim holds for |
| Web service / API | handler → query / render | request fields, validation, DB call or template, response |
| CLI / tool | argv → core transform → write | flags that change behavior, file formats, error paths |
| Library | public API → algorithm → primitive | preconditions, complexity, allocation/copy points |
| Compiler / interpreter | parse → IR pass → emit | AST/IR node, rewrite rule, invariant |
| Frontend | route → component → effect | props/state, API call, render output |

If a repo mixes types (e.g. Python training code + a serving layer), make each a branch with its own terminal definition.

## When the default taxonomy does not fit

The table is a default, not a law. The grill in step 2 exists because these
shapes are common and none of them is "five encoders and a backbone":

- **Monorepo** → one explorer per deployable, or a meta-map whose branches are
  deployables and whose leaves are their public contracts.
- **Framework / plugin host** → global is the request/lifecycle; branches are
  extension points; the leaf is the hook call plus one concrete plugin.
- **Compiler / interpreter** → branches are parse / lower / optimize / emit;
  terminal is the IR builder call that performs the rewrite.
- **Data pipeline / DAG** → global is the DAG; branches are operator families;
  terminal is the engine primitive.
- **Notebook / research repo** → branches are data / model / loss / eval; cite
  the function a cell calls, never the cell.
- **Thin SDK / API wrapper** → global is the public API surface; leaves are the
  upstream HTTP/SDK calls.
- **Generated code** → cite the generator/schema and mark the leaf
  `terminal_reason: generated`; do not reverse-engineer the generated file.

Full question bank and exit criteria: `references/grilling.md`.

## Visual rules (short version)

- Canvas: global `1800×900` or wider; local `1400–1600 × 700–900`.
- Node: 180–260 wide, 80–100 tall (≥ 86 with a shape line); horizontal gap 40–60; one idea per node.
- Shape is a monospace text line, not a pill; long shapes wrap and the node grows.
- Edges are orthogonal with a 9 px arrowhead; do not hand-draw diagonals.
- Paper style: `kind: card|enc|strip|note`; graph style: `kind: tensor|op`.
- Accent color encodes data family: text, video, action, state, neutral. Do not use color decoratively.
- Every edge has a `note` — it is what the inspector shows when clicked.
- Put a footnote with code refs and the concrete dimensions used.

Full schema and layout recipes: `references/spec.md`, `references/grilling.md`, and `references/visual.md`.

## Reference quality bar

DreamZero's explorer is the worked example:

- `/home/charon/workspace/01_project/dreamzero/docs/architecture/explorer.html`
- spec: `/home/charon/workspace/01_project/dreamzero/docs/architecture/structure/`
- 7 branches, 38 views, 12 leaves, all 38 views with code snippets.

Read it before your first build. Match its evidence density, not its subject matter.

## Failure modes to avoid

- **The poster.** A beautiful global figure with no drill-down. Fix: every major box must open.
- **The README in boxes.** Views restate documentation instead of code. Fix: read the function, draw its actual operations.
- **The dead end.** A leaf says "attention" and stops. Fix: open the framework call and show the primitive.
- **The orphan.** A view exists but nothing links to it. `check.py` catches this; fix the drill, do not delete the analysis.
- **The overclaim.** "The output is tanh-clipped" when no tanh exists. Fix: every adjective needs a line; otherwise delete it.
- **The crowd.** 15 nodes on one canvas. Fix: split into a block view and drill.
- **The glossary dump.** Dozens of terms, every noun defined, no link back to the diagram. Fix: 8–30 terms chosen by "what stops a newcomer", one sentence each, every card with a `views:` jump target.
- **The alphabet soup.** `BTKGH,BSKH->BKGTS` printed with no symbol table, or a table that only expands the acronym. Fix: define every letter, say what it counts and how `K`/`G`/`N` relate, and keep literals in a sentence.
- **The containment edge.** A repeated block has FFN, norm, or attention nodes hanging off it with arrows, because the author needed to reach their detail pages. Fix: those nodes are inside the block; make them `kind: note` callouts with `drill` and no edges, and show internals in a separate view.
- **The single-output assumption.** The function returns `[prefix, suffix]` or a tuple, but the diagram shows one block output that splits. Fix: read the `return`, draw one lane per stream, and label each edge with the element it carries.
- **The unowned weight.** A training branch draws the optimizer, the FSDP
  mesh, and the checkpoint, but never says which tensors receive a gradient. Fix:
  read `freeze_filter` / `requires_grad` / the optimizer's parameter groups and
  build the matrix; "we finetune" is not an answer.
- **The universal freeze badge.** A node labelled "frozen" with no config
  attached, when the filter only freezes it for the LoRA variant. Fix: add
  `param_when` and drill to the matrix; if the node mixes states, split it.
- **The norm catch-all.** One "RMSNorm / adaRMS" node stands in for pre-attention, pre-FFN, and final norms, with no indication which stream it belongs to. Fix: name the site, and give each final norm its own lane.
